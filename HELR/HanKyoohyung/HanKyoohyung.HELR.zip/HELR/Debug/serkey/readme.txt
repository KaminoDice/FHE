The folder to save public keys from HEAAN scheme
