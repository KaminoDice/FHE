/*
* Copyright (c) by CryptoLab inc.
* This program is licensed under a
* Creative Commons Attribution-NonCommercial 3.0 Unported License.
* You should have received a copy of the license along with this
* work.  If not, see <http://creativecommons.org/licenses/by-nc/3.0/>.
*/

#include "GD.h"

#include <NTL/ZZ.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>    // std::shuffle
#include <array>        // std::array
#include <random>       // std::default_random_engine
#include <chrono>       // std::chrono::system_clock

using namespace NTL;

/**
 * Load data from train file, extract data to X and Y, transform Y{-0,+1} to Y{-1,+1};
 * More importantly, since the label is Y{-1,+1}, it would always use y*X together after,
 * so it is necessary to combine y*X here to X:
 *   change class label Y{-0,+1} to Y{-1,+1}
 *   change data entry if Y=+1 :   X{ 0, 1, 1, 0, ...}
 *   change data entry if Y=-1 :   X{ 0,-1,-1, 0, ...}
 *
 * @param  : path : path to train file or test file, whose first row contains text string rather than number information
 *                eg. col num = 1580 (include the first row); row num = 104 (include Y Cancer_status)
 *                Cancer_status,BRCA_status,Family_history_1,Family_history_2,SNP1,SNP2,......
 *                0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,0,1,0,1,0,0,1,0,......................
 *                0,0,0,0,1,0,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,1,1,1,1,0,0,......................
 *                0,0,0,0,0,1,1,0,1,0,0,0,1,0,0,1,0,0,1,1,0,0,1,1,0,1,1,......................
 *                1,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,0,1,0,1,0,0,0,0,1,1,1,......................
 *                1,0,0,0,0,0,0,1,1,0,0,1,0,0,0,0,0,1,1,1,0,1,0,0,1,0,0,......................
 *                1,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1,0,0,0,1,1,1,0,0,0,1,......................
 *                ............................................................................
 *                ............................................................................
 *                return:
 *                -1,-0,-0,-0,-0,-0,-0,-1,-1,-0,-0,-1,-0,-0,-1,-0,-1,-0,......................
 *                -1,-0,-0,-0,-1,-0,-0,-0,-0,-1,-1,-0,-0,-1,-0,-0,-0,-0,......................
 *                -1,-0,-0,-0,-0,-1,-1,-0,-1,-0,-0,-0,-1,-0,-0,-1,-0,-0,......................
 *                +1,+0,+0,+0,+0,+0,+1,+0,+0,+0,+0,+1,+0,+0,+1,+0,+0,+1,......................
 *                +1,+0,+0,+0,+0,+0,+0,+1,+1,+0,+0,+1,+0,+0,+0,+0,+0,+1,......................
 *                +1,+0,+0,+0,+0,+0,+1,+0,+0,+0,+0,+1,+1,+0,+0,+0,+1,+0,......................
 *                ............................................................................
 *                ............................................................................
 *
 * @param  : factorDim : dimension of the raw data [X:y]
 * @param  : sampleDim : the number of rows in the data, except for the first row which is a interpretation.
 * @param  : isfirst : is Y at the beginning of each row ?
 * @return :
 * @author : no one
 */
double** GD::zDataFromFile(string& path, long& factorDim, long& sampleDim, bool isfirst) {
	vector<vector<double>> zline;
	factorDim = 1; 	// dimension of x
	sampleDim = 0;	// number of samples
	ifstream openFile(path.data());
	if(openFile.is_open()) {
		string line, temp;
		getline(openFile, line);
		long i;
		size_t start, end;
		for(i = 0; i < line.length(); ++i) if(line[i] == ',' ) factorDim++;

		while(getline(openFile, line)){
			vector<double> vecline;
			do {
				end = line.find_first_of (',', start);
				temp = line.substr(start,end);
				vecline.push_back(atof(temp.c_str()));
				start = end + 1;
			} while(start);
			zline.push_back(vecline);
			sampleDim++;
		}
	} else {
		cout << "Error: cannot read file" << endl;
	}

	double** zData = new double*[sampleDim];
	if(isfirst) {
		for(long j = 0; j < sampleDim; ++j){
			double* zj = new double[factorDim];
			zj[0] = 2 * zline[j][0] - 1;               // change class label Y{0,1} to Y{-1,+1}
			for(long i = 1; i < factorDim; ++i){       // change data entry Y=-1       X{0,-1}
				zj[i] = zj[0] * zline[j][i];           // change data entry Y= 1       X{0, 1}
			}
			zData[j] = zj;
		}
	} else {
		for(long j = 0; j < sampleDim; ++j){
			double* zj = new double[factorDim];
			zj[0] = 2 * zline[j][factorDim - 1] - 1;
			for(long i = 1; i < factorDim; ++i){
				zj[i] = zj[0] * zline[j][i-1];
			}
			zData[j] = zj;
		}
	}
	return zData;
}

/**
 * Shuffle the order of each row in zData.
 *
 * @param  : zData : double** zData =
 *                -1,-0,-0,-0,-0,-0,-0,-1,-1,-0,-0,-1,-0,-0,-1,-0,............................
 *                -1,-0,-0,-0,-1,-0,-0,-0,-0,-1,-1,-0,-0,-1,-0,-0,............................
 *                -1,-0,-0,-0,-0,-1,-1,-0,-1,-0,-0,-0,-1,-0,-0,-1,............................
 *                +1,+0,+0,+0,+0,+0,+1,+0,+0,+0,+0,+1,+0,+0,+1,+0,............................
 *                +1,+0,+0,+0,+0,+0,+0,+1,+1,+0,+0,+1,+0,+0,+0,+0,............................
 *                +1,+0,+0,+0,+0,+0,+1,+0,+0,+0,+0,+1,+1,+0,+0,+0,............................
 *
 * @param  : factorDim : dimension of the raw data [X:y]
 * @param  : sampleDim : the number of rows in the data, except for the first row which is a interpretation.
 * @param  : isfirst :
 * @return :
 *                -1,-0,-0,-0,-0,-1,-1,-0,-1,-0,-0,-0,-1,-0,-0,-1,............................
 *                +1,+0,+0,+0,+0,+0,+1,+0,+0,+0,+0,+1,+0,+0,+1,+0,............................
 *                +1,+0,+0,+0,+0,+0,+1,+0,+0,+0,+0,+1,+1,+0,+0,+0,............................
 *                -1,-0,-0,-0,-1,-0,-0,-0,-0,-1,-1,-0,-0,-1,-0,-0,............................
 *                -1,-0,-0,-0,-0,-0,-0,-1,-1,-0,-0,-1,-0,-0,-1,-0,............................
 *                +1,+0,+0,+0,+0,+0,+0,+1,+1,+0,+0,+1,+0,+0,+0,+0,............................
 * @author : no one
 */
void GD::shuffleZData(double** zData, long factorDim, long sampleDim) {
	srand(time(NULL));
	double* tmp = new double[factorDim];
	for (long i = 0; i < sampleDim; ++i) {
		long idx = i + rand() / (RAND_MAX / (sampleDim - i) + 1);
		copy(zData[i], zData[i] + factorDim, tmp);
		copy(zData[idx], zData[idx] + factorDim, zData[i]);
		copy(tmp, tmp + factorDim, zData[idx]);
	}
}

/**
 * Shift the range of each element in the same column to the range [-1,+1];
 * In fact, it nomalize the data to the range [0, 1] since it combine y*X to X before.
 *
 * @param  : zData : double** zData =
 *                1,1,1,1,1,1,1,1,......................................................
 *                1,2,2,2,2,2,2,2,......................................................
 *                1,3,3,3,3,3,3,3,......................................................
 *                1,4,4,4,4,4,4,4,......................................................
 *                1,5,5,5,5,5,5,5,......................................................
 *                1,6,6,6,6,6,6,6,......................................................
 *
 * @param  : factorDim : dimension of the raw data [X:y]
 * @param  : sampleDim : the number of rows in the data.
 * @return :
 *                1,0.166667,0.166667,0.166667,0.166667,0.166667,0.166667,0.166667,.....
 *                1,0.333333,0.333333,0.333333,0.333333,0.333333,0.333333,0.333333,.....
 *                1,0.5,0.5,0.5,0.5,0.5,0.5,0.5,........................................
 *                1,0.666667,0.666667,0.666667,0.666667,0.666667,0.666667,0.666667,.....
 *                1,0.833333,0.833333,0.833333,0.833333,0.833333,0.833333,0.833333,.....
 *                1,1,1,1,1,1,1,1,......................................................
 * @author : no one
 */
void GD::normalizeZData(double** zData, long factorDim, long sampleDim) {
	long i, j;
	double m;
	for (i = 0; i < factorDim; ++i) {
		m = 0.0;
		for (j = 0; j < sampleDim; ++j) {
			m = max(m, abs(zData[j][i]));
		}

		if(m < 1e-10) continue;

		for (j = 0; j < sampleDim; ++j) {
			zData[j][i] /= m;
		}
	}
}
/**
 * Use GD::normalizeZData to both the train file and the test file.
 *
 * @author : no one
 */
void GD::normalizezData2(double** zDataLearn, double** zDataTest, long factorDim, long sampleDimLearn, long sampleDimTest) {
	long i, j;
	double m;
	for (i = 0; i < factorDim; ++i) {
		m = 0.0;
		for (j = 0; j < sampleDimLearn; ++j) {
			m = max(m, abs(zDataLearn[j][i]));
		}
		for (j = 0; j < sampleDimTest; ++j) {
			m = max(m, abs(zDataTest[j][i]));
		}
		if(m < 1e-10) continue;
		for (j = 0; j < sampleDimLearn; ++j) {
			zDataLearn[j][i] /= m;
		}
		for (j = 0; j < sampleDimTest; ++j) {
			zDataTest[j][i] /= m;
		}
	}
}

/**
 * let each wData[i] and vData[i]  =  the sum of each elem in the same column / ( 1<<(long)ceil(log2(sampleDim)) ).
 * don't konw why ??? It could be the reason that the packing technology SNU they used need this form.
 *
 * @param  :
 * @return :
 * @author : no one
 */
void GD::initialWDataVDataAverage(double* wData, double* vData, double** zData, long factorDim, long sampleDim) {
	long sdimBits = (long)ceil(log2(sampleDim));
	long sdimPow = 1 << sdimBits;
	for (long i = 0; i < factorDim; ++i) {
		double tmp = 0.0;
		for (long j = 0; j < sampleDim; ++j) {
			tmp += zData[j][i];
		}
		tmp /= sdimPow;
		wData[i] = tmp;
		vData[i] = tmp;
	}
}
/**
 * let each wData[i] and vData[i]  =  0. In this way, it may let the input range of sigmoid function be small.
 *
 * @param  :
 * @return :
 * @author : no one
 */
void GD::initialWDataVDataZero(double* wData, double* vData, long factorDim) {
	for (long i = 0; i < factorDim; ++i) {
		wData[i] = 0.0;
		vData[i] = 0.0;
	}
}

/**
 * plainIP = plain Inner Product
 * GD::plainIP(X, w,,) = X*w    (X is a matrix, w is a column vector)
 * Let double a[m][n], b[n]; then set double res[m]; and make res[i] = InnerProduct(a[i][n], b[n]).
 *
 * @param  > a : double** a = zData
 * @return :
 * @author no one
 */
double* GD::plainIP(double** a, double* b, long factorDim, long sampleDim) {
	double* res = new double[sampleDim]();  // each element of res will be inited to zero.
	for (long j = 0; j < sampleDim; ++j) {
		for(long i = 0; i < factorDim; ++i) {
			res[j] += a[j][i] * b[i];
		}
	}
	return res;
}

double* GD::plainSigmoid(long approxDeg, double** zData, double* ip, long factorDim, long sampleDim, double gamma) {
	double* grad = new double[factorDim]();
	if(approxDeg == 3) {
		for (long i = 0; i < factorDim; ++i) {
			for (long j = 0; j < sampleDim; ++j) {
				// g3(x) = 0.5 - 1.20096*(x/8) + 0.81562*(x/8)^3
				grad[i] += (degree3[0] + ip[j] * degree3[1] + pow(ip[j], 3) * degree3[2]) * zData[j][i];
			}
			grad[i] *= gamma;
		}
	} else if(approxDeg == 5) {
		for (long i = 0; i < factorDim; ++i) {
			for (long j = 0; j < sampleDim; ++j) {
				// g5(x) = 0.5 - 1.53048*(x/8) + 2.3533056*(x/8)^3 - 1.3511295*(x/8)^5
				grad[i] += (degree5[0] + ip[j] * degree5[1] + pow(ip[j], 3) * degree5[2] + pow(ip[j], 5) * degree5[3]) * zData[j][i];
			}
			grad[i] *= gamma;
		}
	} else {
		for (long i = 0; i < factorDim; ++i) {
			for (long j = 0; j < sampleDim; ++j) {
				// g7(x) = 0.5 - 1.73496*(x/8) + 4.19407*(x/8)^3 - 5.43402*(x/8)^5 + 2.50739*(x/8)^7
				grad[i] += (degree7[0] + ip[j] * degree7[1] + pow(ip[j], 3) * degree7[2] + pow(ip[j], 5) * degree7[3] + pow(ip[j], 7) * degree7[4]) * zData[j][i];
			}
			grad[i] *= gamma;
		}
	}
	return grad;
}

void GD::plainLGDstep(double* wData, double* grad, long factorDim) {
	for (long i = 0; i < factorDim; ++i) {
		wData[i] -= grad[i];
	}
}

void GD::plainMLGDstep(double* wData, double* vData, double* grad, long factorDim, double eta) {
	for (long i = 0; i < factorDim; ++i) {
		vData[i] = eta * vData[i] + grad[i];
		wData[i] -= vData[i];
	}
}

void GD::plainNLGDstep(double* wData, double* vData, double* grad, long factorDim, double eta) {
	for (long i = 0; i < factorDim; ++i) {
		double tmpw = vData[i] - grad[i];
		vData[i] = (1.0 - eta) * tmpw + eta * wData[i];
		wData[i] = tmpw;
	}
}

void GD::plainLGDL2step(double* wData, double* grad, long factorDim, double lambda) {
	//TODO: implement method
}

void GD::plainMLGDL2step(double* wData, double* vData, double* grad, long factorDim, double eta, double lambda) {
	//TODO: implement method
}

void GD::plainNLGDL2step(double* wData, double* vData, double* grad, long factorDim, double eta, double lambda) {
	//TODO: implement method
}

void GD::plainLGDiteration(long approxDeg, double** zData, double* wData, long factorDim, long sampleDim, double gamma) {
	double* ip = plainIP(zData, wData, factorDim, sampleDim);
	double* grad = plainSigmoid(approxDeg, zData, ip, factorDim, sampleDim, gamma);
	plainLGDstep(wData, grad, factorDim);
	delete[] ip;
	delete[] grad;
}

void GD::plainMLGDiteration(long approxDeg, double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta) {
	double* ip = plainIP(zData, wData, factorDim, sampleDim);
	double* grad = plainSigmoid(approxDeg, zData, ip, factorDim, sampleDim, gamma);
	plainMLGDstep(wData, vData, grad, factorDim, eta);
	delete[] ip;
	delete[] grad;
}


void GD::plainNLGDiteration(long approxDeg, double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta) {
	double* ip = plainIP(zData, vData, factorDim, sampleDim);
	double* grad = plainSigmoid(approxDeg, zData, ip, factorDim, sampleDim, gamma);
	plainNLGDstep(wData, vData, grad, factorDim, eta);

	delete[] ip;
	delete[] grad;
}

void GD::plainLGDL2iteration(long approxDeg, double** zData, double* wData, long factorDim, long sampleDim, double gamma, double lambda) {
	//TODO: implement method
}

void GD::plainMLGDL2iteration(long approxDeg, double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta, double lambda) {
	//TODO: implement method
}

void GD::plainNLGDL2iteration(long approxDeg, double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta, double lambda) {
	//TODO: implement method
}

//-----------------------------------------

double GD::trueIP(double* a, double* b, long size) {
	double res = 0.0;
	for(long i = 0; i < size; ++i) {
		res += a[i] * b[i];
	}
	return res;
}

void GD::trueLGDiteration(double** zData, double* wData, long factorDim, long sampleDim, double gamma) {
	double* grad = new double[factorDim]();

	for(long j = 0; j < sampleDim; ++j) {
		double ip = trueIP(wData, zData[j], factorDim);
		double tmp = (ip > 15.0) ? 0 : (ip < -15.0) ? -1.0 : - 1. / (1. + exp(ip));
		for(int i = 0; i < factorDim; ++i) {
			grad[i] += tmp * (double) zData[j][i];
		}
	}

	for (int i = 0; i < factorDim; ++i) {
		wData[i] -= gamma * grad[i];
	}
	delete[] grad;
}

void GD::trueMLGDiteration(double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta) {
	double* grad = new double[factorDim]();

	for(long j = 0; j < sampleDim; ++j) {
		double ip = trueIP(wData, zData[j], factorDim);
		double tmp = (ip > 15.0) ? 0 : (ip < -15.0) ? -1.0 : - 1. / (1. + exp(ip));
		for(long i = 0; i < factorDim; ++i) {
			grad[i] += tmp * (double) zData[j][i];
		}
	}

	for (int i = 0; i < factorDim; ++i) {
		vData[i] = eta * vData[i] + gamma * grad[i];
		wData[i] -= vData[i];
	}
	delete[] grad;
}

void GD::trueNLGDiteration(double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta) {
	double* grad = new double[factorDim]();

	for(long j = 0; j < sampleDim; ++j) {
		double ip = trueIP(vData, zData[j], factorDim);
		double tmp = (ip > 15.0) ? 0 : (ip < -15.0) ? -1.0 : - 1. / (1. + exp(ip));
		for(long i = 0; i < factorDim; ++i) {
			grad[i] += tmp * (double) zData[j][i];
		}
	}
	for (long i = 0; i < factorDim; ++i) {
		double tmpw = vData[i] - gamma * grad[i];
		vData[i] = (1.0 - eta) * tmpw + eta * wData[i];
		wData[i] = tmpw;
	}
	delete[] grad;
}

void GD::trueLGDL2iteration(double** zData, double* wData, long factorDim, long sampleDim, double gamma, double lambda) {
	//TODO: implement method
}

void GD::trueMLGDL2iteration(double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta, double lambda) {
	//TODO: implement method
}

void GD::trueNLGDL2iteration(double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta, double lambda) {
	//TODO: implement method
}

void GD::calculateAUC(double** zData, double* wData, long factorDim, long sampleDim, double& correctness, double& auc) {
	cout << "w:";
	for (long i = 0; i < factorDim; ++i) {
		cout << wData[i] << ",";
	}
	cout << endl;

	long TN = 0, FP = 0;

    vector<double> thetaTN;
    vector<double> thetaFP;

    for(int i = 0; i < sampleDim; ++i){
        if(zData[i][0] > 0){
            if(GD::trueIP(zData[i], wData, factorDim) < 0) TN++;
            thetaTN.push_back(zData[i][0] * GD::trueIP(zData[i] + 1, wData + 1, factorDim - 1));
        } else{
            if(GD::trueIP(zData[i], wData, factorDim) < 0) FP++;
            thetaFP.push_back(zData[i][0] * GD::trueIP(zData[i] + 1, wData + 1, factorDim - 1));
        }
    }

    correctness = 100.0 - (100.0 * (FP + TN) / sampleDim);
//    cout << "Failure rate: (y = 1) " << TN << "/" << thetaTN.size() << " + (y = 0) " << FP << "/" ;
//    cout << thetaFP.size() << " = " <<  (100.0 * (FP + TN) / sampleDim) << " %." << endl;
    cout << "Correctness: " << correctness  << " %." << endl;

    if(thetaFP.size() == 0 || thetaTN.size() == 0) {
        cout << "n_test_yi = 0 : cannot compute AUC" << endl;
        auc = 0.0;
    } else{
        auc = 0.0;
        for(long i = 0; i < thetaTN.size(); ++i){
            for(long j = 0; j < thetaFP.size(); ++j){
                if(thetaFP[j] <= thetaTN[i]) auc++;
            }
        }
        auc /= thetaTN.size() * thetaFP.size();
        cout << "AUC: " << auc << endl;
    }
}


double GD::calculateMSE(double* wData1, double* wData2, long factorDim) {
    double res= 0.0;

    for(long i = 0; i < factorDim; ++i) {
        res += pow(wData1[i] - wData2[i], 2.0);
    }
    res /= factorDim;
    cout << "MSE = " << res << endl;
    return res;
}


double GD::calculateNMSE(double* wData1, double* wData2, long factorDim) {
    double res= 0.0;

    for(long i = 0; i < factorDim; ++i) {
        res += pow(wData1[i], 2.0);
    }
    res /= factorDim;

    double mse = GD::calculateMSE(wData1, wData2, factorDim);
    res = mse / res;

    cout << "NMSE = " << res << endl;
    return res;

}
