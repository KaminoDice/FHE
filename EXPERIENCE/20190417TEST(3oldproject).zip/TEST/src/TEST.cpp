//============================================================================
// Name        : TEST.cpp
// Author      : John L. Smith
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <math.h>
#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>    // std::shuffle
#include <array>        // std::array
#include <random>       // std::default_random_engine
#include <chrono>       // std::chrono::system_clock

using namespace std;

int Main() {
	cout << "Hello World!!!" << endl; // prints Hello World!!!
	long factorDimTrain = 0, sampleDimTrain = 0, factorDimTest = 0, sampleDimTest = 0;
    // GD::zDataFromFile(trainfile, factorDimTrain, sampleDimTrain, isYfirst);
	//double** GD::zDataFromFile(string& path, long& factorDim, long& sampleDim, bool isfirst) {
	string path("./data/data103x1579.txt");
	long factorDim = factorDimTrain;
	long sampleDim = sampleDimTrain;
	bool isfirst = true;

	vector<vector<double>> zline;
	factorDim = 1; 	// dimension of x
	sampleDim = 0;	// number of samples
	ifstream openFile(path.data());
	if(openFile.is_open()) {
		string line, temp;
		getline(openFile, line);
		cout<<line<<endl;
		long i;
		size_t start=0, end;
		for(i = 0; i < line.length(); ++i) if(line[i] == ',' ) factorDim++;

		while(getline(openFile, line)){
			vector<double> vecline;
			do {
				end = line.find_first_of (',', start);
				temp = line.substr(start,end);
				vecline.push_back(atof(temp.c_str()));
				start = end + 1;
			} while(start);
			zline.push_back(vecline);
			for(int i=0;i<vecline.size();++i) cout<<vecline[i]<<",";cout<<endl;
			sampleDim++;
		}
	} else {
		cout << "Error: cannot read file" << endl;
	}

	cout<<sampleDim<<endl;

	double** zData = new double*[sampleDim];
	if(isfirst) {
		for(long j = 0; j < sampleDim; ++j){
			double* zj = new double[factorDim];
			zj[0] = 2 * zline[j][0] - 1;        // change class label Y{0,1} to Y{-1,+1}
			for(long i = 1; i < factorDim; ++i){// change data entry Y=-1  X{0,-1}
				zj[i] = zj[0] * zline[j][i];    // change data entry Y= 1  X{0, 1}
			}
			zData[j] = zj;
			for(int i=0;i<factorDim;++i) cout<<zj[i]<<",";cout<<endl;
		}
	} else {
		for(long j = 0; j < sampleDim; ++j){
			double* zj = new double[factorDim];
			zj[0] = 2 * zline[j][factorDim - 1] - 1;
			for(long i = 1; i < factorDim; ++i){
				zj[i] = zj[0] * zline[j][i-1];
			}
			zData[j] = zj;
			//for(int i=0;i<factorDim;++i) cout<<zj[i]<<",";cout<<endl;
		}
	}

	cout<<"HELLO AGAIN"<<endl;

	//void GD::normalizeZData(double** zData, long factorDim, long sampleDim) {
		long i, j;
		double m;
		for (i = 0; i < factorDim; ++i) {
			m = 0.0;
			for (j = 0; j < sampleDim; ++j) {
				m = max(m, abs(zData[j][i]));
			}

			if(m < 1e-10) continue;

			for (j = 0; j < sampleDim; ++j) {
				zData[j][i] /= m;
			}
		}
	   for(i=0; i<sampleDim; ++i)
	   {
		   for(j=0;j<factorDim;++j)
			   cout<<zData[i][j]<<",";
		   cout<<endl;
	   }

		long sdimBits = (long)ceil(log2(9));
		long sdimPow = 1 << sdimBits;
		cout<<sdimBits<<endl;
		cout<<sdimPow<<endl;


	/*
		long sampleDim = 0, factorDim = 0;
		double** zData = GD::zDataFromFile(trainfile, factorDim, sampleDim, isYfirst);
		GD::shuffleZData(zData, factorDim, sampleDim);

		TestGD::testPlainNLGDFOLD(fold, zData, factorDim, sampleDim, isYfirst, numIter, kdeg, gammaUp, gammaDown, isInitZero);

long fold, double** zData, long factorDim, long sampleDim,
			bool isYfirst, long numIter, long kdeg, double gammaUp, double gammaDown, bool isInitZero


	long sampleDimTest = sampleDim / fold;
	long sampleDimTrain = sampleDim - sampleDimTest;

    // pvData : used for GD::plainNLGDiteration
	double* pwData = new double[factorDim];
	double* pvData = new double[factorDim];
    // twData : used for GD::trueNLGDiteration
	double* twData = new double[factorDim];
	double* tvData = new double[factorDim];

	double **zDataTrain, **zDataTest;

	zDataTrain = new double*[sampleDimTrain];
	zDataTest = new double*[sampleDimTest];

	GD::normalizeZData(zData, factorDim, sampleDim);
	GD::shuffleZData(zData, factorDim, sampleDim);

	double plaincor, plainauc, truecor, trueauc;
	double averplaincor = 0, averplainauc = 0, avertruecor = 0, avertrueauc = 0;

	for (long fnum = 0; fnum < fold; ++fnum) {
		cout << " !!! START " << fnum + 1 << " FOLD !!! " << endl;

		for (long i = 0; i < sampleDimTest; ++i) {
			zDataTest[i] = zData[fnum * sampleDimTest + i];
		}
		for (long j = 0; j < fnum; ++j) {
			for (long i = 0; i < sampleDimTest; ++i) {
				zDataTrain[j * sampleDimTest + i] = zData[j * sampleDimTest + i];
			}
		}
		for (long i = (fnum + 1) * sampleDimTest; i < sampleDim; ++i) {
			zDataTrain[i - sampleDimTest] = zData[i];
		}

		if(isInitZero) {
			GD::initialWDataVDataZero(pwData, pvData, factorDim);
			GD::initialWDataVDataZero(twData, tvData, factorDim);
		} else {
			GD::initialWDataVDataAverage(pwData, pvData, zDataTrain, factorDim, sampleDimTrain);
			GD::initialWDataVDataAverage(twData, tvData, zDataTrain, factorDim, sampleDimTrain);
		}

		//-----------------------------------------

		double alpha0, alpha1, eta, gamma;

		alpha0 = 0.01;
		alpha1 = (1. + sqrt(1. + 4.0 * alpha0 * alpha0)) / 2.0;

		for (long iter = 0; iter < numIter; ++iter) {
			eta = (1 - alpha0) / alpha1;
			cout << eta << endl;
			gamma = gammaDown > 0 ? gammaUp / gammaDown / sampleDimTrain : gammaUp / (iter - gammaDown) / sampleDimTrain;
			GD::plainNLGDiteration(kdeg, zDataTrain, pwData, pvData, factorDim, sampleDimTrain, gamma, eta);
            GD::plainNLGDiteration(long approxDeg, double** zData, double* wData, double* vData, long factorDim, long sampleDim, double gamma, double eta) {
	        double* ip = plainIP(zData, vData, factorDim, sampleDim);

double* GD::plainIP(double** a, double* b, long factorDim, long sampleDim) {
	double* res = new double[sampleDim]();  // each element of res will be inited to zero.
	for (long j = 0; j < sampleDim; ++j) {
		for(long i = 0; i < factorDim; ++i) {
			res[j] += a[j][i] * b[i];
		}
	}
	return res;
}


			GD::trueNLGDiteration(zDataTrain, twData, tvData, factorDim, sampleDimTrain, gamma, eta);

			alpha0 = alpha1;
			alpha1 = (1. + sqrt(1. + 4.0 * alpha0 * alpha0)) / 2.0;
		}
		cout << "------PLAIN-------" << endl;
		GD::calculateAUC(zDataTest, pwData, factorDim, sampleDimTest, plaincor, plainauc);
		cout << "------------------" << endl;

		cout << "-------TRUE-------" << endl;
		GD::calculateAUC(zDataTest, twData, factorDim, sampleDimTest, truecor, trueauc);
		cout << "------------------" << endl;

		averplaincor += plaincor;
		averplainauc += plainauc;
		avertruecor += truecor;
		avertrueauc += trueauc;

		cout << " !!! STOP " << fnum + 1 << " FOLD !!! " << endl;
		cout << "------------------" << endl;
	}

	cout << "Average Plain correctness: " << averplaincor << "%" << endl;
	cout << "Average Plain AUC: " << averplainauc << endl;
	cout << "Average True correctness: " << avertruecor << "%" << endl;
	cout << "Average True AUC: " << avertrueauc << endl;
}	*/

	return 0;
}
