# HEAAN

- This version is Asiacrypt2017 implementation. 

- For the latest version of HEAAN please go to https://github.com/snucrypto/HEAAN

- You can also find this version in https://github.com/snucrypto/HEAAN/releases/tag/1.0

# License
Copyright (c) by CryptoLab inc. This program is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License. You should have received a copy of the license along with this work. If not, see http://creativecommons.org/licenses/by-nc/3.0/.
