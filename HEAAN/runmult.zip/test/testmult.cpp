#include "Ciphertext.h"
#include "Common.h"
#include "EvaluatorUtils.h"
#include "HEAAN.h"
#include "Key.h"
#include "NumUtils.h"
#include "Plaintext.h"
#include "Ring2Utils.h"
#include "Scheme.h"
#include "SchemeAlgo.h"
#include "SecretKey.h"
#include "SerializationUtils.h"
#include "StringUtils.h"
#include "TestScheme.h"
#include "TimeUtils.h"
#include "Context.h"
#include "Ring2Utils.h"

#include <NTL/ZZX.h>
#include <iomanip>

using namespace std;
using namespace NTL;

int main() {
	long logN = 10;
	long logQ = 65;
	long logp = 16;
	long logSlots = 8;
	long slots = 1 << logSlots;
	Context context(logN, logQ);

	double* a = new double[slots];
	double* b = new double[slots];
	double* ab = new double[slots];
	for (long i = 0; i < slots; ++i) {
		a[i] = cos(i);
		b[i] = sin(i);
		ab[i] = a[i] * b[i];
	}
	
	ZZX polyA = context.encode(a, slots, logp);
	ZZX polyB = context.encode(b, slots, logp);
	
	ZZX polyC;
	Ring2Utils::mult(polyC, polyA, polyB, context.Q, context.N);
	
	complex<double>* result = context.decode(polyC, slots, 2 * logp, logQ);
	for (long i = 0; i < slots; ++i) {
		cout<<"~~~~~~~~~~~~"<<setw(9)<<i<<"~~~~~~~~~~~~"<<endl;
		cout << result[i] << endl;
		cout << ab[i] << endl;
		cout<<"----------------------------------------"<<endl;
	}
	
	return 0;
}
