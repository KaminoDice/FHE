

import java.math.BigInteger;
import java.util.Random;

public class Const {
    private static final BigInteger ZERO = BigInteger.ZERO;
    private static final BigInteger ONE = BigInteger.ONE;
    private static final BigInteger TWO = new BigInteger("2");
    private static final BigInteger TEN = new BigInteger("10");
     
    public static final int CATEGORY_TYPE_ENTRY = 0;
    public static final int CATEGORY_TYPE_FILE = 1;
    public static final int CATEGORY_TYPE_PHOTO = 2;
    public static final int CATEGORY_TYPE_LINK = 3;
     
}