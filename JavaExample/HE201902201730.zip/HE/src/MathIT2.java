import java.math.BigInteger;

import org.mathIT.algebra.PolynomialZ;

public class MathIT2 {
	private static BigInteger bp = new BigInteger("17");

	//*******************************************
	//*  module the coeff of Zq[x] where q=17.  *
	//*******************************************
	private static PolynomialZ CentredCoeff(PolynomialZ res, BigInteger bp)
	{
		for(BigInteger bi:res.keySet())
		{
			BigInteger v = res.get(bi).mod(bp);
			BigInteger i;// i=n for bp=2n+1or2n
			if(bp.mod(BigInteger.TWO).equals(BigInteger.ZERO))
				i = bp.divide(BigInteger.TWO);
			else
				i = bp.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			if(v.compareTo(i)>0)
				v = v.subtract(bp);
			res.put( bi, v );
		}
		//!!!!!!!!!!!!!!!!!!!!
		return res;
	}
	private static void print(PolynomialZ r) {
		System.out.println();
		System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
		for(BigInteger i=r.getDegree();i.compareTo(BigInteger.ZERO)>=0;i=i.subtract(BigInteger.ONE))
		{
			if(r.get(i)!=null)
			{
				System.out.print(r.get(i)+ " x^" + i + "\t");
			}
		}
		System.out.println();
		System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
	
	}
	
	public static void main(String[] args) {
		
		PolynomialZ p = new PolynomialZ();
		p.put(new BigInteger("4"), new BigInteger("1"));
		p.put(new BigInteger("0"), new BigInteger("1"));

		PolynomialZ g = new PolynomialZ();
		g.put(new BigInteger("3"), new BigInteger("4"));
		g.put(new BigInteger("2"), new BigInteger("-6"));
		g.put(new BigInteger("1"), new BigInteger("7"));
		g.put(new BigInteger("0"), new BigInteger("2"));

		PolynomialZ t = new PolynomialZ();
		t.put(new BigInteger("3"), new BigInteger("-5"));
		t.put(new BigInteger("2"), new BigInteger("1"));
		t.put(new BigInteger("1"), new BigInteger("-5"));
		t.put(new BigInteger("0"), new BigInteger("-2"));

		PolynomialZ s = new PolynomialZ();
		s.put(new BigInteger("3"), new BigInteger("1"));
		s.put(new BigInteger("1"), new BigInteger("-1"));
		s.put(new BigInteger("0"), new BigInteger("1"));

		PolynomialZ e = new PolynomialZ();
		e.put(new BigInteger("2"), new BigInteger("1"));
		e.put(new BigInteger("1"), new BigInteger("1"));
		e.put(new BigInteger("0"), new BigInteger("-1"));

		System.out.println("---------------------------------");
		// ********************************************
		// *                  (g*s)%p+e               *
		// ********************************************
		PolynomialZ res = g.multiply(s).mod(p).plus(e);
		
		
		CentredCoeff(res, bp);
		for(BigInteger bi:res.keySet())
			System.out.println(res.get(bi) + " x^" + bi);
		
		BigInteger TWO = BigInteger.TWO;
		BigInteger ZERO = BigInteger.ZERO;
		BigInteger ONE = BigInteger.ONE;
		PolynomialZ tt = new PolynomialZ(ZERO, TWO.pow(3));
		PolynomialZ qq = new PolynomialZ(ZERO, TWO.pow(5));

		PolynomialZ tem = res.multiply(tt);
		System.out.println("tem : " + tem);
		System.out.println(tem.divide(qq)[0]);
		for(BigInteger i=tem.getDegree();i.compareTo(ZERO)>=0;i=i.subtract(ONE))
		{
			if(tem.get(i)==null) continue;
			System.out.println(tem.get(i).divide(TWO.pow(5)) +"\t"+
			                   tem.get(i).mod(TWO.pow(5)));
		}

		System.out.println("---------------------------------");
		//*******************************************
		//*  module the coeff of Zq[x] where q=17.  *
		//*******************************************
		
		
		for(BigInteger bi:res.keySet())
		{
			BigInteger v = res.get(bi).mod(bp);
			BigInteger i;
			i = bp.divide(BigInteger.TWO);
			if(v.compareTo(i)>0)
				v = v.subtract(bp);
			res.put( bi, v );
		}

		for(BigInteger bi:res.keySet())
			System.out.println(res.get(bi)+ "x^" +bi);
		
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");
		System.out.println("====================================================================================");


		g.put(TWO.pow(3), TWO);
		PolynomialZ zero = new PolynomialZ(ZERO,ZERO);
		System.out.print("p : ");print(p);
		System.out.print("g : ");print(g);
		System.out.print("g.mod(p) : ");print(g.mod(p));
		System.out.print("g.divide(p)[0] : ");print(g.divide(p)[0]);
		System.out.print("g.divide(p)[1] : ");print(g.divide(p)[1]);
		
		System.out.print("g.mod(0) : ");print(g.mod(zero));
		//System.out.print("g.divide(0)[0] : ");print(g.divide(zero)[0]);
		//System.out.print("g.divide(0)[1] : ");print(g.divide(zero)[1]);
		System.out.println("5.mod(34) = " + BigInteger.valueOf(5).mod(BigInteger.valueOf(34)));

	}
}
