import java.io.*;
import java.util.*;
import java.math.*;

import org.mathIT.algebra.PolynomialZ;


public class FandV2{
	private static Random random = new Random();
	private static BigInteger TWO = new BigInteger("2");
	private static BigInteger ONE = BigInteger.ONE;
	private static BigInteger ZERO = BigInteger.ZERO;
	
	// sample a integer from [low, high]
	private static int randomInt(int low, int high)
	{   
        return (random.nextInt(high-low+1) + low);
    }
	
	/**
	 * BigInteger(int numBits, Random rnd) Constructs a randomly generated BigInteger, uniformly distributed over the range [0,   2^numBits - 1].
	 * using this function to get a BigInteger from Rq = {n: -q/2<n<=q/2 } = (-q/2, q/2] = [-q/2+1, q/2].
	 * @param The BigInteger q
	 * @return a BigInteger
	 */
	private static BigInteger RqSampling(BigInteger q)
	{
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		
		///step 1. get a random BigInteger bi from [0, 2^qn).///		
		BigInteger bi = new BigInteger(qn,random);
		///step 2. if bi > q/2 : bi -= q . that make bi shift to [-q/2+1, q/2].///
		if( bi.compareTo(q.divide(TWO)) > 0) 
			bi = bi.subtract(q);
		
		return bi;
	}
	
	/**
	 * @param mu(μ)  : a mean μ(mu);
	 * @param tau(τ) : a tail-cut parameter τ(tau)
	 * @param sigma  : a specific standard deviation σ(sigma)
	 * @return a integer from a bounded discrete Gaussian distribution draw.
	 */
	private static int mu = 0;
	private static int tau = 10;
	private static int GaussianSampling(int sigma)
	{	
		int Xmax = mu + tau*sigma;
		int Xmin = mu - tau*sigma;

		while(true)
		{
			int x = randomInt(Xmin,Xmax);
			double p = 1.0/Math.sqrt(2*Math.PI)/sigma * Math.pow(Math.E, -0.5*(x-mu)/sigma*(x-mu)/sigma);
			double r = random.nextDouble();
			if(r < p) return x;
		}

	}
	
	/**
	 * @param res  : the polynomial
	 * @param q    : from Rq = Zq[x]/... . 
	 * @return the res with coefficients that have been Centered. 
	 */
	private static PolynomialZ CentredCoeff(PolynomialZ res, BigInteger q)
	{
		/// res is a map of < exponent, coefficient >. ///
		for(BigInteger idx : res.keySet())
		{
			BigInteger value = res.get(idx);
			value = value.mod(q);
			
			/// get i = q/2. ///
			BigInteger i;// i=n for q=2n+1or2n   BigInteger.getLowestSetBit() 
			if(q.mod(BigInteger.TWO).equals(BigInteger.ZERO))
				i = q.divide(BigInteger.TWO); // or just BigInteger i = q.divide(BigInteger.TWO);
			else
				i = q.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			
			/// if value>q/2 : value -= q. so that the coefficient shifts. ///
			if(value.compareTo(i) > 0)
				value = value.subtract(q);
			
			res.put( idx, value );
		}
		
		return res;
	}
	
	private static PolynomialZ MOD(PolynomialZ x, PolynomialZ y)
	{
		BigInteger degX = x.getDegree();
		BigInteger degY = y.getDegree();
		
		if(degX.compareTo(degY)>0)
			return x.mod(y);
		else
		if(degX.compareTo(degY)==0)
		{
			if(x.get(degX).compareTo(y.get(degY))>=0) // also need: [x.get(degX)] %  [y.get(degY)] == 0
				return x.mod(y);
			else
				return x; /// will not happen in the case of g(x)%(x^n + 1)!
			}
		else
		if(degX.compareTo(degY)<0)
			return x;
		
		return new PolynomialZ();
	}
	
	private static void print(PolynomialZ r) {
		System.out.println();
		System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
		int c=0;
		for(BigInteger i=r.getDegree();i.compareTo(ZERO)>=0;i=i.subtract(ONE))
		{
			if(r.get(i)!=null && r.get(i).compareTo(ZERO)!=0)
			{
				System.out.print(r.get(i)+ " x^" + i + "\t");
				c++;
				if(c>12) break;
			}
		}
		System.out.println();
		System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
		System.out.println();
	}
	private static void print(PolynomialZ r, int main) {
		
		//System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
		int c=0;
		System.out.print("( ");
		String gap = "    ";
		List<BigInteger> idxs = new ArrayList<BigInteger>(r.keySet());
		for(BigInteger i : idxs )
		{
			if(r.get(i)!=null && r.get(i).compareTo(ZERO)!=0)
			{
				if(i.equals(ZERO)) {
					System.out.print(r.get(i));
					continue;
				}
				if(i.equals(ONE)) {
					if(r.get(i).compareTo(ONE)!=0)
					{
						System.out.print(r.get(i)+ "x" + gap + "+" + gap );
					    continue;
					}else {
						System.out.print("x" + gap + "+" + gap );
					    continue;
					}
				}
				
				if(r.get(i).equals(ONE)) 
					System.out.print("x^" + i + gap + "+" + gap);
				else   
					System.out.print(r.get(i)+ "x^" + i + gap + "+" + gap);
				
				c++;
				if(c>12) break;
			}
		}
		System.out.print(" )");
		//System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
	}
	public static void main() {
		Map<Integer,Integer> map = new TreeMap<Integer,Integer>();
		for(int i=0;i<10000;i++)
		{
			int k = GaussianSampling(6);
			if(map.containsKey(k))
				map.put(k, map.get(k)+1);
			else
				map.put(k, 1);
		}
		for(int k : map.keySet())
		{
			System.out.printf("%5d : ",k);
			StringBuffer sb = new StringBuffer();
			for(int i=0;i<map.get(k)/10;i++) sb.append("*");
			System.out.println(sb);
		}
	}
	public static void main(String args){
		/**
		 * Notes:
		 * Yes: (  x^5	+  2 ) / (  x^6	+  1 )  = 0 ...  (  x^5	+  2 )
		 * NO : (  x^5	+  2 ) % (  x^6	+  1 )  =  (  )
		 * Yes: (  x^6	+  1 ) % (  x^5	+  2 )  =  ( -2x^1	+  1 )
		 * NO : (  x^5	+  2 ) % ( 2x^5	+  1 )  =  (   1 )
		 */
	
		PolynomialZ g = new PolynomialZ();
		g.put(new BigInteger("7777"), new BigInteger("1"));
		//g.put(new BigInteger("1"), new BigInteger("2"));
		g.put(new BigInteger("0"), new BigInteger("-1"));
		System.out.print("g = ");print(g);System.out.println(); 
		
		PolynomialZ p = new PolynomialZ();
		p.put(new BigInteger("2"), new BigInteger("1"));
		p.put(new BigInteger("0"), new BigInteger("1"));
		System.out.print("p = ");print(p);System.out.println();
		
		System.out.println("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ");
		
		print(g);
		System.out.print(" % ");
		print(p);
		System.out.print("  =  ");
		print(g.mod(p));
		System.out.print("  <>  ");
		print(MOD(g, p));
		
	}
	public static void main(String[] args){
		// 1s = 10^3ms = 10^6us = 10^9ns
		long beg = System.nanoTime();

		// Notation:
		//   Zq[x] denote polynomial whose coefficients belong to Zq.
		//   Zq is the set of integers {n: -q/2<n<=q/2 }.
		//   Rq = Zq[x]/(x^(2^(d-1)) + 1)
		//   ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~  
		//   d = 13 (4095 degree polynomials)
		//   q = 2^128
		//   t = 2^15
		//   σ = 16 (sigma)
		int d = 13;
		BigInteger q = TWO.pow(128); 
		BigInteger t = TWO.pow(15); 
		int sigma = 16;
		String mstr = "36";
		//Stage.1 Key Generation
		//  Step.1 The secret key, Ks, is simply a uniform random draw from R2(-1,1].
		//         sample a 2^(d-1) binary vector for the polynomial coefficients.
		PolynomialZ Ks = new PolynomialZ();       //Ks.put( ni, ai );	fx = ai*x^ni	 
		for(BigInteger i=ZERO;i.compareTo(TWO.pow(d-1))<0;i=i.add(ONE)){
			Ks.put(i, BigInteger.valueOf(random.nextInt(2)));
		}
		System.out.print("Ks : ");print(Ks);
		//  Step.2 The public key, Kp, is a vector containing two polynomials:
		//         Kp = (Kp1, Kp2) = ([-(a*Ks + e)]q, a)   a ~ Rq, e ~ X(0,σ)
		PolynomialZ a = new PolynomialZ();	 
		for(BigInteger i=ZERO;i.compareTo(TWO.pow(d-1))<0;i=i.add(ONE)){
			a.put(i, RqSampling(q));
		}
		System.out.print("a : ");print(a);
		PolynomialZ e = new PolynomialZ();	 
		for(BigInteger i=ZERO;i.compareTo(TWO.pow(d-1))<0;i=i.add(ONE)){
			e.put(i, BigInteger.valueOf(GaussianSampling(sigma)));
		}		
		System.out.print("e : ");print(e);
		PolynomialZ fx = new PolynomialZ();	
		fx.put(TWO.pow(d-1), ONE);
		fx.put(ZERO, ONE);
		System.out.print("fx : ");print(fx);

		PolynomialZ Kp1;
		PolynomialZ zero = new PolynomialZ(ZERO, ZERO);		
		Kp1 = zero.minus( MOD(a.multiply(Ks), fx).plus(e) );		
		CentredCoeff(Kp1, q);
		System.out.print("Kp1 : ");print(Kp1);
		PolynomialZ Kp2 = a;

		//Stage.2 Encryption
		//  Step.1 An integer message m is first represented as m(x)∈ Rt.
		BigInteger m = new BigInteger(mstr);
		String mxs = m.toString(2);
		PolynomialZ mx = new PolynomialZ();	 
		for(int i=0;i<mxs.length();i++){
			mx.put(BigInteger.valueOf(i), new BigInteger(""+(mxs.charAt(mxs.length()-i-1))) );
		}		
		System.out.print("mx(2) = "+mx.evaluate(TWO)+" : ");print(mx);
		//  Step.2 Encryption then renders a cipher text which is a vector containing two polynomials:
		//         c = (c1,c2) = ( [Kp1*u + e1 + det*m(x)]q, [Kp2*u + e2]q )
		//         u,e1,e2 ~ X(0,σ)   det = [q/t] 
		PolynomialZ det = new PolynomialZ(BigInteger.ZERO, q.divide(t));
		PolynomialZ mu = new PolynomialZ();
		PolynomialZ e1= new PolynomialZ();
		PolynomialZ e2= new PolynomialZ();
		for(BigInteger i=ZERO;i.compareTo(TWO.pow(d-1))<0; i=i.add(ONE)){
			mu.put(i, BigInteger.valueOf(GaussianSampling(sigma)));
			e1.put(i, BigInteger.valueOf(GaussianSampling(sigma)));
			e2.put(i, BigInteger.valueOf(GaussianSampling(sigma)));
		}
		System.out.print("det : ");print(det);
		System.out.print("mu : ");print(mu);
		System.out.print("e1 : ");print(e1);
		System.out.print("e2 : ");print(e2);
		
		
		PolynomialZ c1 = MOD(Kp1.multiply(mu), fx).plus(e1).plus(det.multiply(mx));
		CentredCoeff(c1, q); 
		System.out.print("c1 : ");print(c1);
		
		PolynomialZ c2 = MOD(Kp2.multiply(mu), fx).plus(e2);
		CentredCoeff(c2, q);
		System.out.print("c2 :         ");print(c2);

		

		//Stage.3 Decryption
		//  Step.1 decryption of a cipher text c is by evaluating:
		//              m0(x) = [ [t*[c1 + c2*Ks]q / q ] ]t
		//         so that m = m0(x).
		PolynomialZ res = c1.plus( MOD(c2.multiply(Ks), fx) ); 
		CentredCoeff(res, q);
		
		PolynomialZ tx = new PolynomialZ(ZERO, t);	
		res = tx.multiply(res);
		for(BigInteger idx=ZERO;idx.compareTo(fx.getDegree())<0;idx=idx.add(ONE))
		{
			if(res.get(idx)!=null)
			{
				/// FOR PolynomialZ : .mod is very different from .divide ! ///
				BigInteger coefficient = res.get(idx);
				BigInteger quotient = coefficient.divide(q);
				BigInteger remainder = coefficient.mod(q);
				if(remainder.compareTo(coefficient.divide(TWO)) > 0)
					quotient =quotient.add(ONE);
				
				res.put(idx, quotient);					
			}
		}		
		CentredCoeff(res, t);
		System.out.println("res.evaluate(2) = " + res.evaluate(TWO));
		

		long end = System.nanoTime();
		System.out.println();
		System.out.println("end-beg = " + (end-beg)/1e6 + "ms = " + (end-beg)/1e9 +"s." );


	}

}