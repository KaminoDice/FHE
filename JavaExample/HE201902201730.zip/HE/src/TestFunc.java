import java.io.*;
import java.util.*;
import java.math.*;

import org.mathIT.algebra.PolynomialZ;

// this class file is used to test PolynomialZ modular.

public class TestFunc{
	private static Random random = new Random();
	private static BigInteger TWO = new BigInteger("2");
	private static BigInteger ONE = BigInteger.ONE;
	private static BigInteger ZERO = BigInteger.ZERO;
	
	// sample a integer from [low, high]
	private static int randomInt(int low, int high)
	{   
        return (random.nextInt(high-low+1) + low);
    }
	
	/**
	 * BigInteger(int numBits, Random rnd) Constructs a randomly generated BigInteger, uniformly distributed over the range [0,   2^numBits - 1].
	 * using this function to get a BigInteger from Rq = {n: -q/2<n<=q/2 } = (-q/2, q/2] = [-q/2+1, q/2].
	 * @param The BigInteger q
	 * @return a BigInteger
	 */
	private static BigInteger RqSampling(BigInteger q)
	{
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		
		///step 1. get a random BigInteger bi from [0, 2^qn).///		
		BigInteger bi = new BigInteger(qn,random);
		///step 2. if bi > q/2 : bi -= q . that make bi shift to [-q/2+1, q/2].///
		if( bi.compareTo(q.divide(TWO)) > 0) 
			bi = bi.subtract(q);
		
		return bi;
	}
	
	/**
	 * @param mu(μ)  : a mean μ(mu);
	 * @param tau(τ) : a tail-cut parameter τ(tau)
	 * @param sigma  : a specific standard deviation σ(sigma)
	 * @return a integer from a bounded discrete Gaussian distribution draw.
	 */
	private static int mu = 0;
	private static int tau = 10;
	private static int GaussianSampling(int sigma)
	{	
		int Xmax = mu + tau*sigma;
		int Xmin = mu - tau*sigma;

		while(true)
		{
			int x = randomInt(Xmin,Xmax);
			double p = 1.0/Math.sqrt(2*Math.PI)/sigma * Math.pow(Math.E, -0.5*(x-mu)/sigma*(x-mu)/sigma);
			double r = random.nextDouble();
			if(r < p) return x;
		}
	}
	
	/**
	 * @param res  : the polynomial
	 * @param q    : from Rq = Zq[x]/... . 
	 * @return the res with coefficients that have been Centered. 
	 */
	private static PolynomialZ CentredCoeff(PolynomialZ res, BigInteger q)
	{
		/// res is a map of < exponent, coefficient >. ///
		for(BigInteger idx : res.keySet())
		{
			BigInteger value = res.get(idx);
			value = value.mod(q);
			
			/// get i = q/2. ///
			BigInteger i;// i=n for q=2n+1or2n   BigInteger.getLowestSetBit() 
			if(q.mod(BigInteger.TWO).equals(BigInteger.ZERO))
				i = q.divide(BigInteger.TWO); // or just BigInteger i = q.divide(BigInteger.TWO);
			else
				i = q.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			
			/// if value>q/2 : value -= q. so that the coefficient shifts. ///
			if(value.compareTo(i) > 0)
				value = value.subtract(q);
			
			res.put( idx, value );
		}
		
		return res;
	}

	private static void print(PolynomialZ r) {
	
		//System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
		int c=0;
		System.out.print("( ");
		String gap = "    ";
		List<BigInteger> idxs = new ArrayList<BigInteger>(r.keySet());
		for(BigInteger i : idxs )
		{
			if(r.get(i)!=null && r.get(i).compareTo(ZERO)!=0)
			{
				if(i.equals(ZERO)) {
					System.out.print(r.get(i));
					continue;
				}
				if(i.equals(ONE)) {
					if(r.get(i).compareTo(ONE)!=0)
					{
						System.out.print(r.get(i)+ "x" + gap + "+" + gap );
					    continue;
					}else {
						System.out.print("x" + gap + "+" + gap );
					    continue;
					}
				}
				
				if(r.get(i).equals(ONE)) 
					System.out.print("x^" + i + gap + "+" + gap);
				else   
					System.out.print(r.get(i)+ "x^" + i + gap + "+" + gap);
				
				c++;
				if(c>12) break;
			}
		}
		System.out.print(" )");
		//System.out.println("- - - - - - - - - - - - - - - - - - - - - -");
	}
	public static void main() {
		Map<Integer,Integer> map = new TreeMap<Integer,Integer>();
		for(int i=0;i<10000;i++)
		{
			int k = GaussianSampling(6);
			if(map.containsKey(k))
				map.put(k, map.get(k)+1);
			else
				map.put(k, 1);
		}
		for(int k : map.keySet())
		{
			System.out.printf("%5d : ",k);
			StringBuffer sb = new StringBuffer();
			for(int i=0;i<map.get(k)/10;i++) sb.append("*");
			System.out.println(sb);
		}
	}
	private static PolynomialZ MOD(PolynomialZ x, PolynomialZ y)
	{
		BigInteger degX = x.getDegree();
		BigInteger degY = y.getDegree();
		
		if(degX.compareTo(degY)>0)
			return x.mod(y);
		else
		if(degX.compareTo(degY)==0)
		{
			if(x.get(degX).compareTo(y.get(degY))>=0) // also need: [x.get(degX)] %  [y.get(degY)] == 0
				return x.mod(y);
			else
				return x;
		}
		else
		if(degX.compareTo(degY)<0)
			return x;
		
		return new PolynomialZ();
	}
	public static void main(String[] args){
		/**
		 * Notes:
		 * Yes: (  x^5	+  2 ) / (  x^6	+  1 )  = 0 ...  (  x^5	+  2 )
		 * NO : (  x^5	+  2 ) % (  x^6	+  1 )  =  (  )
		 * Yes: (  x^6	+  1 ) % (  x^5	+  2 )  =  ( -2x^1	+  1 )
		 * NO : (  x^5	+  2 ) % ( 2x^5	+  1 )  =  (   1 )
		 */
	
		PolynomialZ g = new PolynomialZ();
		g.put(new BigInteger("7777"), new BigInteger("1"));
		//g.put(new BigInteger("1"), new BigInteger("2"));
		g.put(new BigInteger("0"), new BigInteger("-1"));
		System.out.print("g = ");print(g);System.out.println(); 
		
		PolynomialZ p = new PolynomialZ();
		p.put(new BigInteger("2"), new BigInteger("1"));
		p.put(new BigInteger("0"), new BigInteger("1"));
		System.out.print("p = ");print(p);System.out.println();
		
		System.out.println("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ");
		
		print(g);
		System.out.print(" % ");
		print(p);
		System.out.print("  =  ");
		print(g.mod(p));
		System.out.print("  <>  ");
		print(MOD(g, p));
		
		
		BigDecimal tlq = new BigDecimal("-3.5241592653");
		tlq = tlq.setScale(0, RoundingMode.HALF_DOWN);
		System.out.println();
		System.out.println(tlq);
		
	}

}