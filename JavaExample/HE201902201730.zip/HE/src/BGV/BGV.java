package BGV;

import java.io.*;
import java.util.*;
import java.math.*;

import org.apache.commons.math3.linear.AnyMatrix;
import org.apache.commons.math3.linear.Array2DRowFieldMatrix;
import org.apache.commons.math3.linear.FieldMatrix;
import org.apache.commons.math3.linear.FieldVector;
import org.apache.commons.math3.util.BigReal;
import org.mathIT.algebra.PolynomialZ;

// add static to avoid [BigInteger ten = Const.TEN;]
import static util.Const.*;
import static util.Polynomial.*;
import static util.Sampling.*;



/**
 * Notation:
 *   q     : modulus in the cipher text space(coefficient modulus) of the form q1*q2*...*qk,where qi are prime
 *   t     : modulus in the plain text space(plain text modulus)
 *   x^n+1 : The polynomial modulus which specifies the ring R
 *   R     : The ring Z[x]/f(x), where f(x) =(x^n+1)=x^(2^(d-1))+1
 *   Ra    : The ring Za[x]/(x^n+1),i.e. same as the ring R but with coefficients reduced modulo a
 *   det   : Quotient on division of q by t, or [q/t]
 *   rt(q) : Remainder on division of q by t, i.e. q = det*t + rt(q), where 0<=rt(q)<t
 *   X     : Error distribution(a truncated discrete Gaussian distribution)
 *   sigma : Standard deviation of X
 *   B     : Bound on the distribution X
 *   Zq[x] : denote polynomial whose coefficients belong to Zq.
 *   Zq    : is the set of integers {n: -q/2<n<=q/2 }.
 *   Rq    : Zq[x]/(x^(2^(d-1)) +1 )
 *   ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
 *   d     : 13(4095 degree polynomials)
 *   q     : 2^128
 *   T     : 2^64(Relinearisation: Version 1 need T. Here Set T a pow of two for convenience)
 *   t     : 2^15
 *   σ     : 16(sigma)
 *   
 *   The scheme FV : SecretKeyGen,PublicKeyGen,EvaluationKeyGen,Encrypt,Decrypt,Add and Multiply.
 *   
 *   
 *   λ     ： the security parameter, representing 2^λ security against known attacks.(λ=100 is a reasonable value.)
 *   n     : 1 for a RLWE-based scheme.   
 */
public class BGV{
	private int d = 6;
	private int n = (int)Math.pow(2, d-1);
	private BigInteger q = TWO.pow(12);//.add(ONE); q=2^128+1 will not work!
	public int qn = q.bitLength();
	private int N = (2*n+1)*qn ;
	
	
	// E.Setup(1^λ,1^μ,b): Use the bit b∈{0,1} to determine whether we are setting parameters for a LWE-based scheme(where d=1)
	// or a RLWE-based scheme(where n=1).Choose a μ-bit modulus q and choose the other parameters( d=d(λ,μ,b),n=n(λ,μ,b),N=[(2n+1)logq],
	// X=X(λ,μ,b) )appropriately to ensure that the scheme is based on a GLWE instance that achieves 2^λ security against known attacks.
	// Let R=Z[x]/(x^d+1) and let params=(q,d,n,N,X).
	
	// E.SecretKeyGen(params):Draw s' <- X^n. Set sk=s <- (1,s'[1],...,s'[n])∈Rq^(n+1)
	private List<Integer> sk = new ArrayList<Integer>();


	private void Setup() {}
	
	
	
 
	private int length = (int)Math.pow(2, d-1);
	
	private BigInteger T = TWO.pow(32);  // WITH ERROR!
	private BigInteger t = TWO.pow(15);
	private int sigma = 16;
	//private PolynomialZ Phi;
	//cyclotomic polynomial  Φ[2^d](x) = x^(2^(d-1)) + 1
	private PolynomialZ Phi;// = new PolynomialZ() { {put(TWO.pow(d-1), ONE);put(ZERO, ONE);} };
	//Map map = new HashMap() {{put("foo", 1); put("bar", 2);}};
	//Here the nested braces create an instance initializer. The object bound to map is not a HashMap, its class is an anonymous class extending HashMap. 
	//(That means if you have a PMD rule about classes needing to declare serial uids then it will complain about this.)
	
	private PolynomialZ     secretkey;
	private PolynomialZ[]   publickey;
	private PolynomialZ[][] relinekey;
	 
	public Map<BigInteger, BigInteger> Message;/// or a Set that just contains the plaintext without crytpotext.
	
	private BGV() {
		this.length = (int)Math.pow(2, d-1);
		
		buildPhi();	
		buildSecretkey();
		buildPublickey();
		buildRelinekey();
	}
	private BGV(int d, BigInteger q, BigInteger T, BigInteger t, int sigma) {
		this.d = d;
		this.q = q;
		this.T = T;
		this.t = t;
		this.sigma = sigma;
		
		this.length = (int)Math.pow(2, d-1);

		buildPhi();
		buildSecretkey();
		buildPublickey();
		buildRelinekey();
	}	
	public int getd() {
		return d;
	}
	public void setd(int d) {
		this.d = d;
		this.length = (int)Math.pow(2, d-1);
		buildPhi();
	}
	public BigInteger getq() {
		return q;
	}
	public void setq(BigInteger q) {
		this.q = q;
	}
	public BigInteger getT() {
		return T;
	}
	public void setT(BigInteger T) {
		this.T = T;
	}
	public BigInteger gett() {
		return t;
	}
	public void sett(BigInteger t) {
		this.t = t;
	}
	public int getsigma() {
		return sigma;
	}
	public void setsigma(int sigma) {
		this.sigma = sigma;
	}
	
	/// Singleton Design Pattern
	private static BGV instance = null;
	public static synchronized BGV getInstance() {
		if(instance == null)
			instance = new BGV();
		return instance;
	}

	private void buildPhi() {
		this.Phi = new PolynomialZ();
		Phi.put(TWO.pow(d-1), ONE);
		Phi.put(ZERO, ONE);
	}
	
	//Stage.1 Key Generation
	//  Step.1 The secret key, Ks, is simply a uniform random draw from R2(-1,1].
	//         sample a 2^(d-1) binary vector for the polynomial coefficients.		
	/// SecretKeyGen(lambda): Sample s <- R2 and output sk = s.
	private PolynomialZ buildSecretkey() {
		this.secretkey = R2Sampling(length);
		return secretkey;
	}

	//  Step.2 The public key, Kp, is a vector containing two polynomials:
	//         Kp = (Kp1, Kp2) = ([-(a*Ks + e)]q, a)   a ~ Rq, e ~ X(0,σ)
	/// PublicKeyGen(sk): Set s = sk, sample a <- Rq, and e <- X. Output pk = ([-(a*s+e)]q, a).
	public PolynomialZ[] buildPublickey() {
		
		PolynomialZ a = RqSampling(q, length);
		PolynomialZ e = GaussianSampling(sigma, length);

		PolynomialZ p0 = a.multiply(secretkey);           p0 = MOD(p0, Phi);
		p0 = p0.plus(e);                                  PolynomialZ zero = new PolynomialZ();
		p0 = zero.minus(p0);
		CentredCoeff(p0, q);
		PolynomialZ p1 = a;
		
		this.publickey = new PolynomialZ[2];
		publickey[0] = p0;
		publickey[1] = p1;
		return publickey;
	}
	//  Step.3 The relinearisation key, rlk, ...		
	/// EvaluationKeyGen(sk,w): For i{0,...,l},sample ai <- Rq, ei <- X. Output
	///                         evk = ([-(ai*s + ei) + w^i*s^2]q, ai).
	/**
	 * Notation:
	 *   A first possible solution is to slice C2 into parts of small norm by choosing a base T
	 *   ( note that T is totally independent of t) and to write C2 in base T,i.e. C2=T^i*C2[i] mod q (i{0...l}),
	 *   with l = [log(q)/log(T)] and the coefficients of C2[i] are in R[T]{(-T/2, T/2])}.
	 *   The relinearisation key rlk then consists of the masked version of T^i*s*s for i=0,...,l:
	 *     rlk = [ ([-(ai*s + ei) + T^i*s*s]q, ai) :  i{0,...,l}]
	 */
	public PolynomialZ[][] buildRelinekey() {

		/// get the qn of q = 2^qn from q.///
		int qn;
		if (q.compareTo(ZERO) < 0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		/// get the Tn of T = 2^Tn from T.///
		int Tn;
		if (T.compareTo(ZERO) < 0)
			Tn = T.bitLength();
		else
			Tn = T.bitLength() - 1;
		int l = qn / Tn; // l = [log(q)/log(T)] = qn/Tn

		this.relinekey = new PolynomialZ[l + 1][2];

		for (int i = 0; i <= l; i++) {

			PolynomialZ ai = RqSampling(q, length);
			
			PolynomialZ ei = GaussianSampling(sigma, length);
			
			PolynomialZ ss = secretkey.multiply(secretkey);    			ss = MOD(ss, Phi);

			PolynomialZ k0 = ai.multiply(secretkey);    			    k0 = MOD(k0, Phi);
			k0 = k0.plus(ei);                                          PolynomialZ zero = new PolynomialZ();
			k0 = zero.minus(k0);
			PolynomialZ T2i = new PolynomialZ(ZERO, T.pow(i));
			PolynomialZ tmp = T2i.multiply(ss);
			k0 = k0.plus(tmp);
			CentredCoeff(k0, q);

			PolynomialZ rlki0 = k0;
			PolynomialZ rlki1 = ai;
			relinekey[i][0] = k0;
			relinekey[i][1] = ai;
		}
		return relinekey;
	}	
	private PolynomialZ getSecretkey() {
		return secretkey;
	}
	public PolynomialZ[] getPublickey() {
		return publickey;
	}
	private PolynomialZ[][] getRelinekey() {
		return relinekey;
	}
	public Map<BigInteger, BigInteger> getMessage() {
		return Message;
	}
	public void setMessage(Map<BigInteger, BigInteger> message) {
		Message = message;
	}
	
	//Stage.2 Encryption
	/**
	 * @param base = 2 (could be other number, need modify this function)
	 * @param message
	 * @return
	 */
	public PolynomialZ[] Encrypt(BigInteger message) {
		//  Step.1 An integer message m is first represented as m(x)∈ Rt.
		PolynomialZ mx = new PolynomialZ();
		long deg = 0;
		for (char ch : message.toString(2).toCharArray()) {//////////////// should rewrite!///////////////////
			mx.put(BigInteger.valueOf(message.toString(2).length() - deg - 1), BigInteger.valueOf(ch - '0'));// work
																												// when
																												// base<10
			deg++;
		}
		// Step.2 Encryption then renders a cipher text which is a vector containing two
		// polynomials:
		// c = (c1,c2) = ( [Kp1*u + e1 + det*m(x)]q, [Kp2*u + e2]q )
		// u,e1,e2 ~ X(0,σ) det = [q/t]
		/// Encrypt(pk,m): For m in Rt, let pk=(p0,p1).Sample u <- R2, and e1,e2 <- X.
		// Compute
		/// ct = ([det*m + p0*u +e1]q, [p1*u + e2]q)
		PolynomialZ det = new PolynomialZ(ZERO, q.divide(t));
		PolynomialZ u  = R2Sampling(length);
		PolynomialZ	e1 = GaussianSampling(sigma, length);
		PolynomialZ	e2 = GaussianSampling(sigma, length);

		PolynomialZ c0 = det.multiply(mx);
		PolynomialZ p0u = publickey[0].multiply(u);       		p0u = MOD(p0u, Phi);
		c0 = c0.plus(p0u).plus(e1);
		CentredCoeff(c0, q);

		PolynomialZ c1 = publickey[1].multiply(u);      		c1 = MOD(c1, Phi);
		c1 = c1.plus(e2);
		CentredCoeff(c1, q);
		
		PolynomialZ[] cryptotext = new PolynomialZ[2];
		cryptotext[0] = c0;
		cryptotext[1] = c1;
		
		return cryptotext;
	}
	
	//Stage.3 Decryption
	//  Step.1 decryption of a cipher text c is by evaluating:
	//              m0(x) = [ [t*[c1 + c2*Ks]q / q ] ]t
	//         so that m = m0(x).		
	/// Decrypt(sk,ct): Set s = sk, c0 = ct[0], and c1 = ct[1]. Output
	public PolynomialZ Decrypt(PolynomialZ[] cryptotext) {
		
		PolynomialZ c0 = cryptotext[0];
		PolynomialZ c1 = cryptotext[1];

		PolynomialZ result = c1.multiply(secretkey);          result = MOD(result, Phi);
		result = c0.plus(result);
		CentredCoeff(result, q);

		BigDecimal tlq = new BigDecimal(t).divide(new BigDecimal(q));
		for (BigInteger idx : result.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(result.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			result.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(result, t);
		
		return result;
	}

	//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~Add(ct0,ct1):Output(ct0[0]+ct1[0],ct0[1]+ct1[1])~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
	public PolynomialZ[] Add(PolynomialZ[] ct0, PolynomialZ[] ct1) {

		PolynomialZ C0 = ct0[0].plus(ct1[0]);// CentredCoeff(C0, q);
		PolynomialZ C1 = ct0[1].plus(ct1[1]);// CentredCoeff(C1, q);
		
		PolynomialZ[] result = new PolynomialZ[2];
		result[0] = C0;
		result[1] = C1;
		
		return result;
	}
	
	//~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~Multiply(ct0,ct1)~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
	public PolynomialZ[] Multiply(PolynomialZ[] ct0, PolynomialZ[] ct1) {		
		
		PolynomialZ C0 = ct0[0].multiply(ct1[0]);                         		C0 = MOD(C0, Phi);
		BigDecimal tlq = new BigDecimal(t).divide(new BigDecimal(q));
		for (BigInteger idx : C0.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(C0.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			C0.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(C0, q);

		PolynomialZ C1 = ct0[0].multiply(ct1[1]);               		C1 = MOD(C1, Phi);
		PolynomialZ temp = ct0[1].multiply(ct1[0]);             		temp = MOD(temp, Phi);
		C1 = C1.plus(temp);
		for (BigInteger idx : C1.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(C1.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			C1.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(C1, q);

		PolynomialZ C2 = ct0[1].multiply(ct1[1]);                  		C2 = MOD(C2, Phi);
		for (BigInteger idx : C2.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(C2.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			C2.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(C2, q);

		PolynomialZ Ct0 = C0;
		PolynomialZ Ct1 = C1;
		///////////////////////////should pack it a attribute or a bean?///////////////////////////
		/// get the qn of q = 2^qn from q.///
		int qn;
		if (q.compareTo(ZERO) < 0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		/// get the Tn of T = 2^Tn from T.///
		int Tn;
		if (T.compareTo(ZERO) < 0)
			Tn = T.bitLength();
		else
			Tn = T.bitLength() - 1;
		int l = qn / Tn; // l = [log(q)/log(T)] = qn/Tn
		////////////////////////////////////////////////////////////////////////////
		for (int i = 0; i <= l; i++) {
			
			PolynomialZ res2 = new PolynomialZ();
			for (int idx = 0; idx < length; idx++) {
				res2.put(BigInteger.valueOf(idx), C2.get(BigInteger.valueOf(idx)).mod(T));
				CentredCoeff(res2, T);
		
				C2.put(BigInteger.valueOf(idx), C2.get(BigInteger.valueOf(idx)).divide(T));
			}
			Ct0 = Ct0.plus( MOD(relinekey[i][0].multiply(res2), Phi) );
			Ct1 = Ct1.plus( MOD(relinekey[i][1].multiply(res2), Phi) );
		}
		
		PolynomialZ[] result = new PolynomialZ[2];
		result[0] = Ct0;
		result[1] = Ct1;
		
		return result;
	}
	
	public static void print(FieldMatrix<BigReal> m) {
		System.out.println("RowDimension="+m.getRowDimension() + " ; ColomnDimension=" + m.getColumnDimension());
		for(int i=0;i<m.getRowDimension();i++) {
			for(int j=0;j<m.getColumnDimension();j++) {
				System.out.print(m.getEntry(i, j).bigDecimalValue());
				System.out.print('\t');
			}
			System.out.println("\n");
		}
		System.out.println("\n");
	}
	public static void main(String[] args){
		// E.Setup(1^λ,1^μ,b): Use the bit b∈{0,1} to determine whether we are setting parameters for a LWE-based scheme(where d=1)
		// or a RLWE-based scheme(where n=1).Choose a μ-bit modulus q and choose the other parameters( d=d(λ,μ,b),n=n(λ,μ,b),N=[(2n+1)logq],
		// X=X(λ,μ,b) )appropriately to ensure that the scheme is based on a GLWE instance that achieves 2^λ security against known attacks.
		// Let R=Z[x]/(x^d+1) and let params=(q,d,n,N,X).
		int d=5;
		int n=(int) Math.pow(2, d);
		BigInteger q = TWO.pow(19);//.add(ONE);
		int qn = q.bitLength();
		int N = (2*n+1)*qn +1 ;
		
		// E.SecretKeyGen(params):Draw s' <- X^n. Set sk=s <- (1,s'[1],...,s'[n])∈Rq^(n+1)
		FieldMatrix<BigReal> secretkey;
		FieldMatrix<BigReal> s1;
		
		BigReal[] arrayo = new BigReal[n];  // for s' = s1
		BigReal[] array0 = new BigReal[n+1];// for secretkey
		array0[0] = new BigReal(1);
		for(int i=0;i<n;i++) {
			int ei = GaussianSampling(3);
			arrayo[i] = new BigReal(ei);
			array0[i+1] = new BigReal(ei);
		}
		s1 = new Array2DRowFieldMatrix(arrayo);
		secretkey = new Array2DRowFieldMatrix(array0);		
		
		// E.PublicKeyGen(params,sk):Takes as input a secret key sk and the params.Generate matrix A' <- Rq^(N*n) uniformly and a vector e <- X^N
		// and set b <- A's' + 2e. Set A to be the (n+1)-column matrix consisting of b followed by the n columns of -A'.(Observe:A*s=2e.) 
		// Set the public key pk = A.
		// Step 1. construct A'
		FieldMatrix<BigReal> A1;
		FieldMatrix<BigReal> _A1;
		BigReal[][] array1 = new BigReal[N][n]; // for  A' =  A1
		BigReal[][] arrayl = new BigReal[N][n]; // for -A' = _A1
		for(int i=0;i<N;i++) {
			for(int j=0;j<n;j++) {
				BigInteger rq = RqRSampling(q);
				array1[i][j] = new BigReal(rq);
				arrayl[i][j] = new BigReal(rq.negate());
			}
		}
		A1 = new Array2DRowFieldMatrix(array1);
		_A1= new Array2DRowFieldMatrix(arrayl);
		
		// Step 2. construct e
		FieldMatrix<BigReal> e;
		FieldMatrix<BigReal> _2e;
		BigReal[] array2 = new BigReal[N];
		BigReal[] array3 = new BigReal[N];
		for(int i=0;i<N;i++) {
			int ei = GaussianSampling();
			array2[i] = new BigReal(ei);
			array3[i] = new BigReal(2*ei);
		}
		e  = new Array2DRowFieldMatrix(array2);
		_2e = new Array2DRowFieldMatrix(array3);
		// Step 3. construct b <- A's'+2e
		FieldMatrix<BigReal> b = A1.multiply(s1).add(_2e);

		// Step 4. construct publickey = A
		FieldMatrix<BigReal> publickey;
		BigReal[][] array6 = new BigReal[N][n+1];
		for(int i=0;i<N;i++) array6[i][0] = b.getEntry(i, 0);
		for(int i=0;i<N;i++) {
			for(int j=1;j<n+1;j++) {
				array6[i][j] = _A1.getEntry(i, j-1);
			}
		}
		publickey = new Array2DRowFieldMatrix(array6);
		FieldMatrix<BigReal> A = publickey;
		
		// E.Enc(params,pk,m): To encrypt a message m∈R2, set m <-(m,0,...,0)∈Rq^(n+1), sample r <- R2^N
		// and output the ciphertext c <- m + A.T*r ∈ Rq^(n+1).
		int message = 1;// m = 0 or 1.
		BigReal[] array4 = new BigReal[n+1];
		for(int i=0;i<n+1;i++) array4[i] = new BigReal(0);
		array4[0] = new BigReal(message);
		FieldMatrix<BigReal> m = new Array2DRowFieldMatrix(array4);
		BigReal[] array5 = new BigReal[N];
		for(int i=0;i<N;i++) array5[i]=new BigReal(R2Sampling());
		FieldMatrix<BigReal> r = new Array2DRowFieldMatrix(array5);
		FieldMatrix<BigReal> c = m.add(A.transpose().multiply(r));
		
		// E.Dec(params,sk,c): output m <- [ [<c,s>]q ]2
		FieldMatrix<BigReal> result = c.transpose().multiply(secretkey);
		System.out.println(result.getColumnDimension());
		System.out.println(result.getRowDimension());
		print(result);
		System.out.println("<c,s>="+result.getEntry(0, 0).bigDecimalValue().toBigInteger());
		System.out.println("[<c,s>]q="+result.getEntry(0, 0).bigDecimalValue().toBigInteger().mod(q));
		BigInteger res = result.getEntry(0, 0).bigDecimalValue().toBigInteger();
		System.out.println("   message    = "+message);
		System.out.print("[ [<c,s>]q ]2 = ");System.out.println(res.mod(q).mod(TWO));
		System.out.println("WWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		// BitDecomp(x∈Rq^n, q) decomposes x into its bit representation. Namely, write x = 2^j*uj (j=0...logq),
		// where all of the vectors uj are in R2^n, and output (u0,u1,...,u[logq]).
		FieldMatrix<BigReal> x = secretkey;
		BigInteger qq = q;
		int qqn = qq.bitLength();
		FieldMatrix<BigReal>[] output = new Array2DRowFieldMatrix[qqn+1];
		for(int i=0;i<output.length;i++) {
			FieldMatrix<BigReal> temp = x.copy();
			for(int j=0;j<x.getRowDimension();j++)
			{
				temp.setEntry(j, 0, new BigReal(x.getEntry(j, 0).bigDecimalValue().toBigInteger().mod(TWO)));
				x.setEntry(j, 0, x.getEntry(j, 0).divide(new BigReal(TWO)));
			}
			output[i] = temp;
		}
		// Powersof2(x∈Rq^n, q) outputs the vector(x,2x,...,2^[logq]x).
		FieldMatrix<BigReal> x2 = secretkey;
		BigInteger qq2 = q;
		int qq2n = qq2.bitLength();
		FieldMatrix<BigReal>[] output2 = new Array2DRowFieldMatrix[qq2n+1];
		for(int i=0;i<output2.length;i++) {
			FieldMatrix<BigReal> temp = x2.copy();
			for(int j=0;j<x2.getRowDimension();j++)
			{
				temp.setEntry(j, 0, x.getEntry(j, 0).multiply(new BigReal(TWO)));
				x.setEntry(j, 0, x.getEntry(j, 0).multiply(new BigReal(TWO)));
			}
			output[i] = temp;
		}		
		// FHE.Setup(1^λ, 1^L, b): Take as input the security parameter, a number of levels L, and a bit b.
		// Use the bit b∈{0,1} to determine whether we are setting parameters for a LWE-based scheme(where
		// d = 1) or a RLWE-based scheme(where n = 1). Let μ=μ(λ,L,b)=θ(logλ + logL)be a parameter that we 
		// will specify in detail later. For j = L(input level of circuit) to 0 (output level), run 
		// params[j] << E.Setup(1^λ,1^((j+1)μ),b) to obtain a ladder of decreasing moduli from qL( (L+1)μ bits )
		// down to q0(μ bits). For j = L-1 to 0, replace the value of dj in params[j] with d = dL and the 
		// distribution Xj with X = XL. That is, the ring dimension and noise distribution do not depend on 
		// the circuit level, but the vector dimension nj still might.
		
		// FHE.KeyGen({params[j]}): For j = L down to 0, do the following:
		//  1. Run sj << E.SecretKeyGen(params[j]) and Aj << E.publicKeyGen(params[j],sj).
		//  2. Set s'j << sj o sj . That is, s'j is a tensoring of sj with itself whose coefficients are each
		//     the product of two coefficients of sj in Rqj.
		//  3. Set s''j << BitDecomp(s'j, qj).
		//  4. Run tao << SwitchKeyGen(s''j,s[j-1]).(Omit this step when j = L.)
		// The secret key sk consists of the sj 's and the public key pk consists of the Aj 's and tao 's.
		
		// FHE.Enc(params,pk,m): Take a message in R2. Run E.Enc(AL, m).
		
		// FHE.Dec(params,sk,c): Suppose the ciphertext is under key sj. Run E.Dec(sj,c).
		// (The ciphertext could be augmented with an index indicating which level it belongs to.)
		
		// FHE.Add(pk,c1,c2): Take two ciphertexts encrypted under the same sj. If they are not initially, 
		// use FHE.Refresh(below) to make it so.) Set c3 << c1 + c2 mod qj. Interpret c3 as a ciphertext under
		// s'j(s'j 's coefficients include all of sj's since s'j = sj o sj and sj 's first coefficient is 1)
		// and output:                                c4 << FHE.Refresh(c3, tao, q[j],q[j-1])
		
		// FHE.Mult(pk,c1,c2): Takes two ciphertexts encrypted under the same sj. If they are not initially,
		// use FHE.Refresh(below) to make it so.) First, multiply: the new ciphertext, under the secret key
		// s'j = sj o sj, is the coefficient vector c3 of the linear equation Lc1c2(X o X). Then, output:
		//                                            c4 << FHE.Refresh(c3, tao, q[j],q[j-1])
		
		// FHE.Refresh(c, tao,q[j],q[j-1]): Takes a ciphertext encrypted under s'j, the auxiliary information tao
		// to facilitate key switching, and the current and next moduli qj and q[j-1]. Do the following:
		//  1. Expand: Set c1 << Powersof2(c,qj). (Observe: <c1,s''j> = <c,s'j> mod qj by Lemma 2.)
		//  2. Switch Moduli: Set c2 << Scale(c1,qj,q[j-1],2), a ciphertext under the key s''j for modulus q[j-1].
		//  3. Switch Keys: Output c3 << SwitchKey(tao,c2,q[j-1]), a ciphertext under the key s[j-1] for modulus q[j-1].
		
		
		
		
		
		
		// default : column first
//		BigReal[] array = { new BigReal(ZERO), new BigReal(ONE), new BigReal(TWO) };
//		FieldMatrix<BigReal> M1 = new Array2DRowFieldMatrix(array);
//		
//		FieldMatrix<BigReal> M2 = new Array2DRowFieldMatrix(array);
//		
//		FieldMatrix<BigReal> M3 = M1.multiply(M2.transpose());
//		for(int i=0;i<M3.getRowDimension();i++) {
//			for(int j=0;j<M3.getColumnDimension();j++) {
//				System.out.print(M3.getEntry(i, j).bigDecimalValue());
//				System.out.print('\t');
//			}
//			System.out.println();
//		}
//		



	}

}