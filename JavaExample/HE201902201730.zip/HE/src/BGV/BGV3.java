package BGV;

import java.io.*;
import java.util.*;
import java.math.*;

import org.apache.commons.math3.linear.AnyMatrix;
import org.apache.commons.math3.linear.Array2DRowFieldMatrix;
import org.apache.commons.math3.linear.FieldMatrix;
import org.apache.commons.math3.linear.FieldVector;
import org.apache.commons.math3.util.BigReal;
import org.mathIT.algebra.PolynomialZ;

import util.Matrix;
import util.Vector;

// add static to avoid [BigInteger ten = Const.TEN;]
import static util.Const.*;
import static util.Polynomial.*;
import static util.Matrix.*;
import static util.Sampling.*;




/**
 * Notation:
 *   d     : 13(4095 degree polynomials)
 *   q     : 2^128
 *   T     : 2^64(Relinearisation: Version 1 need T. Here Set T a pow of two for convenience)
 *   t     : 2^15
 *   σ     : 16(sigma)
 *   
 *   The scheme FV : SecretKeyGen,PublicKeyGen,EvaluationKeyGen,Encrypt,Decrypt,Add and Multiply.
 *     
 *   λ     ： the security parameter, representing 2^λ security against known attacks.(λ=100 is a reasonable value.)
 *   n     : 1 for a RLWE-based scheme.   
 */
public class BGV3{
	private int d;
	private int n;
	private BigInteger q;// q=2^128+1 will not work!
	private int N;
	private util.Vector secretkey;
	private Matrix publickey;
	private Matrix A;
	private Matrix ciphertext;
	
	private List<util.Vector> FHEsecretkeys;
	private List<Matrix[]> FHEpublickeys;

	
	private List<BigInteger> qL;
	private List<Integer> NL;
	
	private int L;

	public BGV3() {
		
	}	
	// E.Setup(1^λ,1^μ,b): Use the bit b∈{0,1} to determine whether we are setting parameters for a LWE-based scheme(where d=1)
	// or a RLWE-based scheme(where n=1).Choose a μ-bit modulus q and choose the other parameters( d=d(λ,μ,b),n=n(λ,μ,b),N=[(2n+1)logq],
	// X=X(λ,μ,b) )appropriately to ensure that the scheme is based on a GLWE instance that achieves 2^λ security against known attacks.
	// Let R=Z[x]/(x^d+1) and let params=(q,d,n,N,X).
	// λ = 7; μ = 128; b = 1;
	private void Setup(int lambda, int mu, int b) {
		// b=0 for a LWE-based scheme(where d = 1)
		// b=1 for a RLWE-based scheme(wheren = 1).
		lambda = 7;
		mu = 128;
		b = 1;
		// Choose a μ-bit modulus q
		q = TWO.pow(mu).add(ONE);
		// Choose the other parameters
		// d = d(λ,μ,b)
		// n = n(λ,μ,b)
		// N = floor( (2n+1)logq ) +1
		// χ = χ(λ,μ,b)
		
		// R = Z[x]/( x^d + 1)
		// params = (q, d, n, N, χ) 
		d = lambda;
		n = (int)Math.pow(2, d-1);
		// logq = q.bitLength()-1; for q = 2^n
		N = (2*n+1)*mu; /////////////////////////WITH ERROR/////
	}
	// E.SecretKeyGen(params):Draw s' <- X^n. Set sk=s <- (1,s'[1],...,s'[n])∈Rq^(n+1)
	public util.Vector secretkeyGen() {
		secretkey = new util.Vector(n+1);
		BigInteger[] data = new BigInteger[n+1];
		data[0] = ONE;
		for(int i=1;i<=n;i++) {
			data[i] = BigInteger.valueOf(GaussianSampling());////////////???///////////////
		}
		secretkey.setData(data);
		return secretkey;
	}
	// E.PublicKeyGen(params,sk):Takes as input a secret key sk and the params.Generate matrix A' <- Rq^(N*n) uniformly and a vector e <- X^N
	// and set b <- A's' + 2e. Set A to be the (n+1)-column matrix consisting of b followed by the n columns of -A'.(Observe:A*s=2e.) 
	// Set the public key pk = A.
	/**
	 * 
	 * @param secretkey
	 * @param N
	 * @return
	 */
	public Matrix publickeyGen(util.Vector secretkey, int N, BigInteger q) {
		// Step 1. construct A'
		int n = secretkey.getColnum()-1;
		Matrix A1 = new Matrix(N,n);
		BigInteger[][] data = new BigInteger[N][n]; // for  A' =  A1
		for(int i=0;i<N;i++) {
			for(int j=0;j<n;j++) {
				data[i][j] = RqRSampling(q);        // ?????????????
			}
		}
		A1.setData(data);
		// Step 2. construct e
		util.Vector e = new util.Vector(N);
		int[] datae = new int[N]; 
		for(int i=0;i<N;i++) datae[i] = GaussianSampling();
		e.setData(datae);
		// Step 3. abstract s' from secretkey(1,s')
		util.Vector s1 = new util.Vector(n);
		BigInteger[] data1 = new BigInteger[n];
		for(int i=0;i<n;i++) {
			data1[i] = secretkey.getEntry(i+1);
		}
		s1.setData(data1);
		// Step 4. construct b << A's'+2e
		Matrix b = A1.multiply(s1.transpose()).add( e.multiply(2).transpose());
		// Step 5. construct publickey = A
		A = new Matrix(N,n+1); 
		BigInteger[][] dataA = new BigInteger[N][n+1];
		for(int i=0;i<N;i++) dataA[i][0] =  b.getEntry(i, 0);
		Matrix A1neg = A1.multiply(-1); // for -A' = _A1
		for(int i=0;i<N;i++) {
			for(int j=1;j<=n;j++) {
				dataA[i][j] = A1neg.getEntry(i, j-1);
			}
		}
		A.setData(dataA);
		
		return A;
	}
	// E.Enc(params,pk,m): To encrypt a message m∈R2, set m <-(m,0,...,0)∈Rq^(n+1), sample r <- R2^N
	// and output the ciphertext c <- m + A.T*r ∈ Rq^(n+1).
	public Matrix Enc(Matrix AL, int message){
		util.Vector m = new util.Vector(n+1);
		int[] data = new int[n+1];
		data[0] = message;
		for(int i=1;i<n+1;i++) data[i] = 0;
		m.setData(data);
		// sample r << R2^N
		util.Vector r = new util.Vector(N);
		int[] datar = new int[N];
		for(int i=0;i<N;i++) datar[i] = R2Sampling();
		r.setData(datar);
		// output the ciphertext c << m + A.T*r
		util.Matrix c = m.transpose().add( AL.transpose().multiply(r.transpose()) );
		
		ciphertext=c;
		return ciphertext;
	}
	// E.Dec(params,sk,c): output m <- [ [<c,s>]q ]2
	//   Attention! : [a]q refers to a mod q, with coefficients reduced into (-q/2, q/2].
	public BigInteger Dec(util.Vector secretkey, Matrix ciphertext){
		Matrix res = ciphertext.transpose().multiply(secretkey.transpose());

		BigInteger message = CentredCoeff(res.getData()[0][0], q).mod(TWO);
		
		//return res;
		return message;
	}
	//----------------------------------------------------------------------------------------------//

	// BitDecomp(x∈Rq^n, q) decomposes x into its bit representation. Namely, write x = 2^j*uj (j=0...logq),
	// where all of the vectors uj are in R2^n, and output (u0,u1,...,u[logq]).
	public util.Vector BitDecomp(util.Vector x, BigInteger q) {
		int floorLog2q = floorLog2(q);
		BigInteger[] u = new BigInteger[x.getColnum()*(floorLog2q+1)];
		BigInteger[] temp = x.getVectorData(); //return a copy of x.data
		int idx = 0;
		for(int i=0;i<=floorLog2q;i++) {
			for(int j=0;j<x.getColnum();j++)
			{
				u[idx] = temp[j].mod(TWO);
				temp[j] = temp[j].divide(TWO);
				
				idx++;
			}			
		}
		
		return new util.Vector(u);
	}
	// Powersof2(x∈Rq^n, q) outputs the vector(x,2x,...,2^[logq]x).
	public util.Vector Powersof2(util.Vector x, BigInteger q) {
		int floorLog2q = floorLog2(q);
		BigInteger[] u = new BigInteger[x.getColnum()*(floorLog2q+1)];
		BigInteger[] temp = x.getVectorData(); // return a copy of x.data 
		int idx = 0;
		for(int i=0;i<=floorLog2q;i++) {
			for(int j=0;j<x.getColnum();j++)
			{
				u[idx] = temp[j];
				temp[j] = temp[j].multiply(TWO);
				
				idx++;
			}			
		}
		
		return new util.Vector(u);
	}
	// SwitchKeyGen(s1∈Rq^n1, s2∈Rq^n2)
	//   Step 1. Run A << E.publicKeyGen(s2, N) for N = n1*[logq].
	//   Step 2. Set B << A + Powersof2(s1)(Add Powersof2(s1)∈Rq^N to A's first column.)
	//           Output τ[s1->s2] = B.
	public Matrix SwitchKeyGen(util.Vector s1, util.Vector s2, BigInteger q) {
		int n1 = s1.getColnum();		
		int N = n1*(floorLog2(q)+1);
		Matrix A = publickeyGen(s2, N, q);
		Matrix powersof2s1 = Powersof2(s1, q);
		Matrix B = A.addToFirstColumn(powersof2s1);
		
		return B;
	}
	// SwitchKey(τ[s1->s2], c1): Output c2 = BitDecomp(c1).T * B
	public Matrix SwitchKey(Matrix B, util.Vector ciphertext, BigInteger q) {
		
		 return BitDecomp(ciphertext, q).transpose().multiply(B);
	}
	public static BigInteger big(int n) {
		return BigInteger.valueOf(n);
	}
	
	// For integer vector x and integers q>p>m, we define x' << Scale(x,q,p,r) to be the R-vector closest 
	// to (p/q)*x that satisfies x' = x mod r.
	public util.Vector Scale(util.Vector x, BigInteger q, BigInteger p, BigInteger r){
		if(q.compareTo(p) <=0) {
			System.out.println("Can not process the Scale!");
			System.exit(-1);
		}
		BigDecimal plq = (new BigDecimal(p).divide(new BigDecimal(q),5, RoundingMode.DOWN));
		BigInteger[] newdata = new BigInteger[x.getColnum()];
		for(int i=0;i<x.getColnum();i++) {
			BigDecimal xi = new BigDecimal(x.getEntry(i));
			BigDecimal betweenpoint = plq.multiply(xi);
			
			BigDecimal K = betweenpoint.subtract(xi).divide(new BigDecimal(r));
			BigDecimal rightK = K.setScale(0, RoundingMode.CEILING); 
			
			BigDecimal x1i = rightK.multiply(new BigDecimal(r)).add(xi);
			if(x1i.subtract(betweenpoint).compareTo(new BigDecimal(0.5).multiply(new BigDecimal(r)))>0)
				x1i = x1i.subtract(new BigDecimal(r));
			
			newdata[i] = x1i.toBigInteger();
		}
		
		return new util.Vector(newdata);
	}

	// FHE.Setup(1^λ, 1^L, b): Take as input the security parameter, a number of levels L, and a bit b.
	// Use the bit b∈{0,1} to determine whether we are setting parameters for a LWE-based scheme(where
	// d = 1) or a RLWE-based scheme(where n = 1). Let μ=μ(λ,L,b)=θ(logλ + logL)be a parameter that we 
	// will specify in detail later. For j = L(input level of circuit) to 0 (output level), run 
	// params[j] << E.Setup(1^λ,1^((j+1)μ),b) to obtain a ladder of decreasing moduli from qL( (L+1)μ bits )
	// down to q0(μ bits). For j = L-1 to 0, replace the value of dj in params[j] with d = dL and the 
	// distribution Xj with X = XL. That is, the ring dimension and noise distribution do not depend on 
	// the circuit level, but the vector dimension nj still might.
	public void FHEsetup(int lambda, int L, int b) {
		int mu = (int) (Math.log(lambda*L)/Math.log(2));
		for(int j=L;j>=0;j--) {
			Setup(lambda, (j+1)*mu, b);
			qL.add(0, this.q);
			NL.add(0, this.N);
		}
	}
	// FHE.KeyGen({params[j]}): For j = L down to 0, do the following:
	//  1. Run sj << E.SecretKeyGen(params[j]) and Aj << E.publicKeyGen(params[j],sj).
	//  2. Set s'j << sj o sj . That is, s'j is a tensoring of sj with itself whose coefficients are each
	//     the product of two coefficients of sj in Rqj.
	//  3. Set s''j << BitDecomp(s'j, qj).
	//  4. Run tao << SwitchKeyGen(s''j,s[j-1]).(Omit this step when j = L.)
	// The secret key sk consists of the sj 's and the public key pk consists of the Aj 's and tao 's.
    public void FHEkeygen() {
    	
    	for(int j=L;j>=0;j--) {
    		// Step 1.
    		util.Vector sj = secretkeyGen();
    		Matrix Aj = publickeyGen(sj, N,qL.get(j));
    		
    		sj.setCiphertextidx(j);
    		FHEsecretkeys.add(0, sj);
    		Matrix[] keys = new Matrix[2];
    		keys[0] = Aj;
    		FHEpublickeys.add(0,keys);
    	}
    	for(int j=L;j>=0;j--) {
    		util.Vector sj = FHEsecretkeys.get(j);
    		Matrix Aj = FHEpublickeys.get(j)[0];
    		
    		// Step 2.
    		util.Vector s1j = sj.transpose().multiply(sj).castAllRowToVector();
    		// Step 3.
    		util.Vector s11j = BitDecomp(s1j,qL.get(j)).castFirstRowToVector();
    		
    		// Step 4.
    		if(j == L) continue;
    		//                                                  qL[?]
    		Matrix B = SwitchKeyGen(s11j,FHEsecretkeys.get(j-1),qL.get(j));
    		
    		// The secret key consists of the sj's and the public key pk consists of the Aj's ant τ's.
    		FHEpublickeys.get(j)[1] = B;		    		
    		
    	}    	
    }
    // FHE.Enc(params,pk,m): Take a message in R2. Run E.Enc(AL, m).
    public Matrix FHEenc(Matrix AL, int message) {    	
    	return Enc(AL, message);
    }
    
	// FHE.Dec(params,sk,c): Suppose the ciphertext is under key sj. Run E.Dec(sj,c).
	// (The ciphertext could be augmented with an index indicating which level it belongs to.)
    public BigInteger FHEdec(util.Vector secretkey, Matrix ciphertxt) {
    	
    	return Dec(secretkey, ciphertext);
    }

	// FHE.Add(pk,c1,c2): Take two ciphertexts encrypted under the same sj. If they are not initially, 
	// use FHE.Refresh(below) to make it so.) Set c3 << c1 + c2 mod qj. Interpret c3 as a ciphertext under
	// s'j(s'j 's coefficients include all of sj's since s'j = sj o sj and sj 's first coefficient is 1)
	// and output:                                c4 << FHE.Refresh(c3, tao, q[j],q[j-1])
    public Matrix FHEadd(Matrix pk, util.Vector c1, util.Vector c2) {
    	// Step 1. ciphertext add
    	Matrix c3 = c1.add(c2);
    	// Step 2. FHE.Refresh(ciphsertext)
    	Matrix c4 = c3;//FHErefresh()
    	
    	return c4;
    }
	// FHE.Mult(pk,c1,c2): Takes two ciphertexts encrypted under the same sj. If they are not initially,
	// use FHE.Refresh(below) to make it so.) First, multiply: the new ciphertext, under the secret key
	// s'j = sj o sj, is the coefficient vector c3 of the linear equation Lc1c2(X o X). Then, output:
	//                                            c4 << FHE.Refresh(c3, tao, q[j],q[j-1])
    public Matrix FHEmult(Matrix publickey,util.Vector c1, util.Vector c2) {
    	// Step 1. multiply: the new ciphertext, under the secret key s1j = sj o sj.
    	util.Vector sj = FHEsecretkeys.get(c1.getCiphertextidx());
    	util.Vector s1j = sj.transpose().multiply(sj).castAllRowToVector();
    	// Step 2. refresh:  c4 << FHE.Refresh()
    	Matrix c4 = FHErefresh(s1j,FHEpublickeys.get(c1.getCiphertextidx())[1], qL.get(c1.getCiphertextidx()),qL.get(c1.getCiphertextidx()-1));
    	
    	return c4;
    }	
	// FHE.Refresh(c, tao,q[j],q[j-1]): Takes a ciphertext encrypted under s'j, the auxiliary information tao
	// to facilitate key switching, and the current and next moduli qj and q[j-1]. Do the following:
	//  1. Expand: Set c1 << Powersof2(c,qj). (Observe: <c1,s''j> = <c,s'j> mod qj by Lemma 2.)
	//  2. Switch Moduli: Set c2 << Scale(c1,qj,q[j-1],2), a ciphertext under the key s''j for modulus q[j-1].
	//  3. Switch Keys: Output c3 << SwitchKey(tao,c2,q[j-1]), a ciphertext under the key s[j-1] for modulus q[j-1].
    public Matrix FHErefresh(util.Vector ciphertext,Matrix B,BigInteger qj,BigInteger qj_1) {
    	util.Vector c1 = Powersof2(ciphertext, qj);
    	//c2 << Scale(c1,qj, q[j-1], 2)
    	util.Vector c2 = Scale(c1,qj,qj_1,TWO);
    	//WITH ERROR
    	Matrix c3 = SwitchKey(FHEpublickeys.get(c2.getCiphertextidx())[1], c2, qj_1);
    	
    	return c3;
    }

}