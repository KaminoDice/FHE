package util;

import java.math.BigInteger;

public class Const {
    public static final BigInteger ZERO = BigInteger.ZERO;
    public static final BigInteger ONE = BigInteger.ONE;
    public static final BigInteger TWO = new BigInteger("2");
    public static final BigInteger TEN = new BigInteger("10");
     
    public static final int CATEGORY_TYPE_ENTRY = 0;
    public static final int CATEGORY_TYPE_FILE = 1;
    public static final int CATEGORY_TYPE_PHOTO = 2;
    public static final int CATEGORY_TYPE_LINK = 3;
     
}