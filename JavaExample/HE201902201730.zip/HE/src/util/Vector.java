package util;

import static util.Const.ZERO;

import java.math.BigInteger;

public class Vector extends Matrix{
	private int ciphertextidx;
	
	public Vector() {
		this.rownum = 1;
	}
	public Vector( int colnum) {
		this.rownum = 1;
		this.colnum = colnum;
		data = new BigInteger[rownum][colnum];
	}
	public Vector(long[] data) {
		this.rownum = 1;
		this.colnum = data.length;
		this.data = new BigInteger[1][colnum];

		for(int j=0;j<colnum;j++) {
			this.data[0][j] = BigInteger.valueOf(data[j]);				
		}
	}	
	public Vector(int[] data) {
		this.rownum = 1;
		this.colnum = data.length;
		this.data = new BigInteger[1][colnum];

		for(int j=0;j<colnum;j++) {
			this.data[0][j] = BigInteger.valueOf(data[j]);				
		}
	}	
	public Vector(BigInteger[] data) {
		this.rownum = 1;
		this.colnum = data.length;
		this.data = new BigInteger[1][colnum];

		for(int j=0;j<colnum;j++) {
			this.data[0][j] = data[j];				
		}
	}	
	
    public int getCiphertextidx() {
		return ciphertextidx;
	}
	public void setCiphertextidx(int ciphertextidx) {
		this.ciphertextidx = ciphertextidx;
	}
	public BigInteger getEntry(int colidx) {
    	return data[0][colidx];
    }
    public BigInteger[] getVectorData() {
    	BigInteger[] temp = new BigInteger[colnum];
    	for(int i=0;i<colnum;i++)
    		temp[i] = this.data[0][i];
    	return temp;
    }
	public void setData(int[] data) {
		this.colnum = data.length;
		for(int j=0;j<colnum;j++) {
			this.data[0][j] = BigInteger.valueOf(data[j]);
		}
	}
	public void setData(long[] data) {
		this.colnum = data.length;
		for(int j=0;j<colnum;j++) {
			this.data[0][j] = BigInteger.valueOf(data[j]);
		}
	}
	public void setData(BigInteger[] data) {
		this.colnum = data.length;
		for(int j=0;j<colnum;j++) {
			this.data[0][j] = (data[j]);
		}
	}
	public Matrix castTOMatrix() {
		int matrownum = this.rownum;
		int matcolnum = this.colnum;
		BigInteger[][] matdata = new BigInteger[matrownum][matcolnum];
		for(int i=0;i<matrownum;i++) {
			for(int j=0;j<matcolnum;j++) {
				matdata[i][j] = this.data[i][j];
			}
		}
		
		Matrix mat = new Matrix(matrownum,matcolnum,matdata);
		return mat;
	}
	public Matrix mutiply(Matrix b) {
		//check
		if(this.colnum != b.getRownum()) {
			System.out.println("Can't process this Matrix * Matrix!");
			System.exit(-1);
		}
		
		int resrownum = this.rownum;
		int rescolnum = b.getColnum();
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				BigInteger sum = ZERO;
				for(int k=0;k<this.colnum;k++)
					sum = sum.add(this.data[i][k].multiply(b.getEntry(k, j)));
				resdata[i][j] = sum;
			}
		}
		
		return new Matrix(resdata);
	}
}