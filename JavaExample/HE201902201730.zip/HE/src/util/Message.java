package util;

import java.math.BigInteger;

import org.mathIT.algebra.PolynomialZ;

import BFV.FandV;

import static util.Const.*;
import static util.Polynomial.*;

// a bug about neg number exist!

public class Message {
	public BigInteger m; // the plain text 
	public int base = 2;
	public PolynomialZ mx;// An integer message m is first represented as m(x)∈ Rt.
	public PolynomialZ[] publickey;// turn out : useless
	public PolynomialZ[] cryptotext;
	public FandV fv = FandV.getInstance();

	public Message() {		
		this.publickey = fv.getPublickey();	
	}
	public Message(Integer m) {
		this( BigInteger.valueOf(m) );	
	}
	public Message(PolynomialZ mx) {
		this.mx = mx;
		this.m = mx.evaluate(BigInteger.valueOf(base));
		this.publickey = fv.getPublickey();	
		this.cryptotext = this.encrypt();		
	}
	public Message(PolynomialZ[] cryptotext) {
		this.cryptotext = cryptotext;
		this.mx = this.decrypt();
		this.m = mx.evaluate(BigInteger.valueOf(base));
		this.publickey = fv.getPublickey();		
	}
	public Message(BigInteger m) {
		this.m = m;
		
		buildMx();
		this.publickey = fv.getPublickey();
		this.cryptotext = fv.Encrypt(m);
	}

	public BigInteger getM() {
		return m;
	}

	public void setM(BigInteger m) {
		this.m = m;
		buildMx();
	}

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
		buildMx();
	}

	public void buildMx() {
		mx = new PolynomialZ();
		int deg = 0;
		BigInteger temp = m;
		BigInteger BASE = BigInteger.valueOf(base);
		while(true) {
			if(m.signum()==-1)
				mx.put(BigInteger.valueOf(deg), temp.mod(BASE).negate());
			else
				mx.put(BigInteger.valueOf(deg), temp.mod(BASE));
			temp = temp.divide(BASE);
			deg++;
			
			if(temp.compareTo(ZERO)==0) break;
		}
	}

	public  PolynomialZ  getMx() {
		return mx;
	}

	public PolynomialZ[] getPublickey() {
		return publickey;
	}
	
	public PolynomialZ[] encrypt() {
		this.cryptotext = fv.Encrypt(m);
		
		return cryptotext;
	}

	public PolynomialZ decrypt() {
		//this.mx==fv.Decrypt(cryptotext); (should be)
		return fv.Decrypt(cryptotext);
	}

	public BigInteger evaluate() {
		return mx.evaluate(BigInteger.valueOf(base));
	}

	public PolynomialZ[] add(PolynomialZ[] cryptotext) {
		return fv.Add(this.cryptotext, cryptotext);
	}

	public PolynomialZ[] multiply(PolynomialZ[] cryptotext) {
		return fv.Multiply(this.cryptotext, cryptotext);
	}

     public static void main(String[] args) {
    	 FandV fv = FandV.getInstance();
    	 
    	 Message m1 = new Message(45);
    	 Message m2 = new Message(-36);
    	 BigInteger M1 = BigInteger.valueOf(45);
    	 BigInteger ans = M1.add(BigInteger.valueOf(-36));
    	 PolynomialZ[] ct1 = m1.encrypt();
    	 PolynomialZ[] ct2 = m2.encrypt();
    	 PolynomialZ[] csum = m1.add(m2.encrypt());
    	 for(int i=0;i<0;i++) {
    		 csum = m1.add(csum);
    		 ans = ans.add(M1);
    	 }
    	 /// m1*m2* {m1*m1*...*m1}[5]

    	 System.out.println(new Message(csum).evaluate());
    	 System.out.println("#########################");
    	 System.out.println(ans);

     }
}