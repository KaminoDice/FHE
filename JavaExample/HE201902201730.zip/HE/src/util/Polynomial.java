package util;

import static util.Const.ONE;
import static util.Const.ZERO;
import static util.Sampling.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.mathIT.algebra.PolynomialZ;

public class Polynomial {

	public static PolynomialZ R2Sampling(int length) {
		PolynomialZ sk = new PolynomialZ();

		for (long i = 0; i < length; i++) {
			int r = randomInt(0, 1);
			sk.put(BigInteger.valueOf(i), BigInteger.valueOf(r));
		}
		
		return sk;
	}
	
	/**
	 * @param res  : the polynomial
	 * @param q    : from Rq = Zq[x]/... . 
	 * @return the res with coefficients that have been Centered. 
	 */
	public static PolynomialZ CentredCoeff(PolynomialZ res, BigInteger q)
	{
		/// res is a map of < exponent, coefficient >. ///
		for(BigInteger idx : res.keySet())
		{
			BigInteger value = res.get(idx);
			value = value.mod(q);
			
			/// get i = q/2. ///
			BigInteger i;// i=n for q=2n+1or2n   BigInteger.getLowestSetBit() 
			if(q.mod(BigInteger.TWO).equals(BigInteger.ZERO))
				i = q.divide(BigInteger.TWO); // or just BigInteger i = q.divide(BigInteger.TWO);
			else
				i = q.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			
			/// if value>q/2 : value -= q. so that the coefficient shifts. ///
			if(value.compareTo(i) > 0)
				value = value.subtract(q);
			
			res.put( idx, value );
		}
		
		return res;
	}
	
	public static PolynomialZ MOD(PolynomialZ x, PolynomialZ y)
	{
		BigInteger degX = x.getDegree();
		BigInteger degY = y.getDegree();
		
		if(degX.compareTo(degY)>0)
			return x=x.mod(y);
		else
		if(degX.compareTo(degY)==0)
		{
			if(x.get(degX).compareTo(y.get(degY))>=0) // also need: [x.get(degX)] %  [y.get(degY)] == 0
				return x=x.mod(y);
			else
				return x; /// will not happen in the case of g(x)%(x^n + 1)!
			}
		else
		if(degX.compareTo(degY)<0)
			return x;
		
		return new PolynomialZ();
	}
	
	public static void print(PolynomialZ r) {
		
		int c=0;
		System.out.print("( ");
		String gap = "    ";
		List<BigInteger> idxs = new ArrayList<BigInteger>(r.keySet());
		for(BigInteger i : idxs )
		{
			if(r.get(i)!=null && r.get(i).compareTo(ZERO)!=0)
			{
				if(i.equals(ZERO)) {
					System.out.print(r.get(i));
					continue;
				}
				if(i.equals(ONE)) {
					if(r.get(i).compareTo(ONE)!=0)
					{
						System.out.print(r.get(i)+ "x" + gap + "+" + gap );
					    continue;
					}else {
						System.out.print("x" + gap + "+" + gap );
					    continue;
					}
				}
				
				if(r.get(i).equals(ONE)) 
					System.out.print("x^" + i + gap + "+" + gap);
				else   
					System.out.print(r.get(i)+ "x^" + i + gap + "+" + gap);
				
				c++;
				if(c>12) {
					System.out.print("..." + gap);
					break;
				}
			}
		}
		System.out.print(" )");
	}
	
	
}
