package util;

import static util.Const.TWO;
import static util.Const.ZERO;
import static util.Const.*;

import java.math.BigInteger;
import java.util.Random;

import org.mathIT.algebra.PolynomialZ;

public class Sampling {

	public static Random random = new Random();

	/// sample a integer from [low, high] ///
	public static int randomInt(int low, int high)
	{   
        return (random.nextInt(high-low+1) + low);
    }
	
	public static int R2Sampling() {
		int r = randomInt(0, 1);
		return r;
	}
	
	// could be optimized!....
	public static int floorLog2(BigInteger q) {
		int qn=0;
		BigInteger res = ONE;
		while(true) {
			res = res.multiply(TWO);
			if(res.compareTo(q)<=0)
				qn++;
			else
				break;
		}
		
		return qn;
	}
	/**
	 * BigInteger(int numBits, Random rnd) Constructs a randomly generated BigInteger, uniformly distributed over the range [0,   2^numBits - 1].
	 * using this function to get a BigInteger from Rq = {n: -q/2<n<=q/2 } = (-q/2, q/2] = [-q/2+1, q/2].
	 * @param The BigInteger q
	 * @return a BigInteger
	 */
	public static BigInteger RqSampling(BigInteger q)
	{
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		
		///step 1. get a random BigInteger bi from [0, 2^qn).///		
		BigInteger bi = new BigInteger(qn,random);
		///step 2. if bi > q/2 : bi -= q . that make bi shift to [-q/2+1, q/2].///
		if( bi.compareTo(q.divide(TWO)) > 0) 
			bi = bi.subtract(q);
		
		return bi;
	}
	/**
	 * BigInteger(int numBits, Random rnd) Constructs a randomly generated BigInteger, uniformly distributed over the range [0,   2^numBits - 1].
	 * @param The BigInteger q
	 * @return a BigInteger
	 */
	////////////////////////------------////////////////////////
	public static BigInteger RqRSampling(BigInteger q)
	{
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength();
		
		///step 1. get a random BigInteger bi from [0, 2^qn).///		
		BigInteger bi = new BigInteger(qn,random);
		bi = bi.mod(q);
		return bi;
	}
	// a ~ Rq
	public static PolynomialZ RqSampling(BigInteger q, int length)
	{
		PolynomialZ a = new PolynomialZ();
		for(int i=0;i<length;i++) {
			BigInteger coefficient = RqSampling(q);
			a.put(BigInteger.valueOf(i), coefficient);
		}
		
		return a;
	}
	
	/**
	 * @param mu(μ)  : a mean μ(mu);
	 * @param tau(τ) : a tail-cut parameter τ(tau)
	 * @param sigma  : a specific standard deviation σ(sigma)
	 * @return a integer from a bounded discrete Gaussian distribution draw.
	 */
	public static int GaussianSampling()
	{	
		final int sigma = 16;
		final int mu = 0;
		final int tau = 10;

		int Xmax = mu + tau*sigma;
		int Xmin = mu - tau*sigma;

		while(true)
		{
			int x = randomInt(Xmin,Xmax);
			double p = 1.0/Math.sqrt(2*Math.PI)/sigma * Math.pow(Math.E, -0.5*(x-mu)/sigma*(x-mu)/sigma);
			double r = random.nextDouble();
			if(r < p) return x;
		}
	}
	public static int GaussianSampling(int sigma)
	{	
		final int mu = 0;
		final int tau = 10;

		int Xmax = mu + tau*sigma;
		int Xmin = mu - tau*sigma;

		while(true)
		{
			int x = randomInt(Xmin,Xmax);
			double p = 1.0/Math.sqrt(2*Math.PI)/sigma * Math.pow(Math.E, -0.5*(x-mu)/sigma*(x-mu)/sigma);
			double r = random.nextDouble();
			if(r < p) return x;
		}
	}
	public static PolynomialZ GaussianSampling(int sigma, int length)
	{	
		PolynomialZ e = new PolynomialZ();
		for(int i=0;i<length;i++) {
			BigInteger coefficient = BigInteger.valueOf(GaussianSampling(sigma));
			e.put(BigInteger.valueOf(i), coefficient);
		}
		
		return e;
	}
	/**
	 * @param res  : the polynomial
	 * @param q    : from Rq = Zq[x]/... . 
	 * @return the res with coefficients that have been Centered. 
	 */
	public static BigInteger CentredCoeff(BigInteger coefficient, BigInteger q)
	{

		BigInteger value = coefficient;
		value = value.mod(q);
			
		/// get i = q/2. ///
		BigInteger i;// i=n for q=2n+1or2n   BigInteger.getLowestSetBit() 
		if(q.mod(BigInteger.TWO).equals(BigInteger.ZERO))
			i = q.divide(BigInteger.TWO); // or just BigInteger i = q.divide(BigInteger.TWO);
		else
			i = q.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			
		/// if value>q/2 : value -= q. so that the coefficient shifts. ///
		if(value.compareTo(i) > 0)
			value = value.subtract(q);
	
		return value;
	}
}
