package util;

// add static to avoid [BigInteger ten = Const.TEN;]
import static util.Const.ONE;
import static util.Const.TWO;
import static util.Const.ZERO;

import java.math.BigInteger;
import java.util.List;

public class Matrix{
	
	protected int rownum = 6;
	protected int colnum = 6;
	protected BigInteger[][] data;
	
	public Matrix() {
		
	}
	public Matrix(int rownum, int colnum) {
		this.rownum = rownum;
		this.colnum = colnum;
		data = new BigInteger[rownum][colnum];
	}
	public Matrix(int rownum, int colnum, BigInteger[][] data) {
		this.rownum = rownum;
		this.colnum = colnum;
		this.data = data;
	}
	public Matrix(long[][] data) {
		this.rownum = data.length;
		this.colnum = data[0].length;
		this.data = new BigInteger[rownum][colnum];

		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				this.data[i][j] = BigInteger.valueOf(data[i][j]);				
			}
		}
	}	
	public Matrix(int[][] data) {
		this.rownum = data.length;
		this.colnum = data[0].length;
		this.data = new BigInteger[rownum][colnum];

		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				this.data[i][j] = BigInteger.valueOf(data[i][j]);				
			}
		}
	}
	public Matrix(BigInteger[][] data) {
		this.rownum = data.length;
		this.colnum = data[0].length;
		this.data = new BigInteger[rownum][colnum];

		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				this.data[i][j] = data[i][j];				
			}
		}
	}	
	public int getRownum() {
		return rownum;
	}
	public void setRownum(int rownum) {
		this.rownum = rownum;
	}
	public int getColnum() {
		return colnum;
	}
	public void setColnum(int colnum) {
		this.colnum = colnum;
	}
	public BigInteger[][] getData() {
		return data;
	}
	public void setData(int[][] data) {
		this.rownum = data.length;
		this.colnum = data[0].length;
		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				this.data[i][j] = BigInteger.valueOf(data[i][j]);
			}
		}
	}
	public void setData(long[][] data) {
		this.rownum = data.length;
		this.colnum = data[0].length;
		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				this.data[i][j] = BigInteger.valueOf(data[i][j]);
			}
		}
	}
	public void setData(BigInteger[][] data) {
		this.rownum = data.length;
		this.colnum = data[0].length;
		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				this.data[i][j] = (data[i][j]);
			}
		}
	}
	public BigInteger getEntry(int rowidx, int colidx) {
		return this.data[rowidx][colidx];
	}
	public void setEntry(int rowidx, int colidx, long entry) {
		this.data[rowidx][colidx] = BigInteger.valueOf((long)entry);
	}
	public void setEntry(int rowidx, int colidx, BigInteger entry) {
		this.data[rowidx][colidx] = entry;
	}	
	public void printmatrix() {
		System.out.println("rownum="+rownum+", colnum="+colnum);
		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				System.out.print(data[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public Matrix transpose() {
		BigInteger[][] newdata = new BigInteger[colnum][rownum];
		for(int i=0;i<rownum;i++) {
			for(int j=0;j<colnum;j++) {
				newdata[j][i] = data[i][j];
			}
		}
		int newrownum = this.colnum;
		int newcolnum = this.rownum;
		
		return new Matrix(newrownum,newcolnum,newdata);
	}
	public util.Vector castFirstRowToVector(){
		int vecrownum = 1;
		int veccolnum = this.colnum;
		BigInteger[] vecdata = new BigInteger[veccolnum];
		
		for(int i=0;i<veccolnum;i++)
			vecdata[i] = this.data[0][i];
		
		util.Vector vec = new util.Vector(vecdata);
		return vec;
	}
	public util.Vector castAllRowToVector(){
		int vecrownum = 1;
		int veccolnum = this.rownum*this.colnum;
		BigInteger[] vecdata = new BigInteger[veccolnum];
		
		int idx=0;
		for(int i=0;i<this.rownum;i++) {
			for(int j=0;j<this.colnum;j++) {
				vecdata[idx] = this.data[i][j];
				idx++;
			}
		}
		
		util.Vector vec = new util.Vector(vecdata);
		return vec;
	}
	public Matrix add(Matrix b) {
		//check
		if(this.rownum!=b.getRownum() || this.colnum != b.getColnum()) {
			System.out.println("Can't process this Matrix+Matrix!");
			System.exit(-1);
		}
		
		int resrownum = this.rownum;
		int rescolnum = this.colnum;
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				resdata[i][j] = this.data[i][j].add(b.getEntry(i, j));
			}
		}
		
		return new Matrix(resdata);
	}
	public Matrix addToFirstColumn(Matrix b) {
		//check
		if(this.rownum != b.getColnum()) {
			System.out.println("Can't Add it To First Column Of this.Matrix");
			System.exit(-1);
		}
		
		int resrownum = this.rownum;
		int rescolnum = this.colnum;
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				resdata[i][j] = this.data[i][j];
			}
		}
		
		for(int i=0;i<this.rownum;i++)
			this.data[i][0] = this.data[i][0].add( b.getData()[0][i] );
		
		return new Matrix(resdata);
	}
	public Matrix addToFirstColumn(List b) {
		//check
		if(this.rownum != b.size()) {
			System.out.println("Can't Add it To First Column Of this.Matrix");
			System.exit(-1);
		}
		
		int resrownum = this.rownum;
		int rescolnum = this.colnum;
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				resdata[i][j] = this.data[i][j];
			}
		}
		
		for(int i=0;i<this.rownum;i++)
			this.data[i][0] = this.data[i][0].add( (BigInteger)b.get(i) );
		
		return new Matrix(resdata);
	}
	public Matrix subtract(Matrix b) {
		//check
		if(this.rownum!=b.getRownum() || this.colnum != b.getColnum()) {
			System.out.println("Can't process this Matrix+Matrix!");
			System.exit(-1);
		}
		
		int resrownum = this.rownum;
		int rescolnum = this.colnum;
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				resdata[i][j] = this.data[i][j].subtract(b.getEntry(i, j));
			}
		}
		
		return new Matrix(resdata);
	}	
	public Matrix multiply(BigInteger b) {
		
		int resrownum = this.rownum;
		int rescolnum = this.colnum;
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				resdata[i][j] = this.data[i][j].multiply(b);
			}
		}
		
		return new Matrix(resdata);
	}
	public Matrix multiply(int b) {
		return this.multiply(BigInteger.valueOf(b));
	}
	public Matrix multiply(long b) {
		return this.multiply(BigInteger.valueOf(b));
	}

	public Matrix multiply(Matrix b) {
		//check
		if(this.colnum != b.getRownum()) {
			System.out.println("Can't process this Matrix*Matrix!");
			System.exit(-1);
		}
		
		int resrownum = this.rownum;
		int rescolnum = b.getColnum();
		BigInteger[][] resdata = new BigInteger[resrownum][rescolnum];
		
		for(int i=0;i<resrownum;i++) {
			for(int j=0;j<rescolnum;j++) {
				BigInteger sum = ZERO;
				for(int k=0;k<this.colnum;k++)
					sum = sum.add(this.data[i][k].multiply(b.getEntry(k, j)));
				resdata[i][j] = sum;
			}
		}
		
		return new Matrix(resdata);
	}

	public static void main(String[] args){
		BigInteger[][] m1 = {
				{ZERO,ONE,TWO},
				{ONE,TWO,TWO}
		};
		BigInteger[] m2 = {ZERO,ONE,TWO};
		
		Matrix M1 = new Matrix(m1);
		Vector M2 = new Vector(m2);
		M1.printmatrix();
		M2.printmatrix();

		
		M1.multiply(M2.transpose()).printmatrix();
		
	}
}