
#ifndef NTL_vec_vec_RR__H
#define NTL_vec_vec_RR__H

#include <NTL/vec_RR.h>

NTL_OPEN_NNS

typedef Vec< Vec<RR> > vec_vec_RR;

NTL_CLOSE_NNS

#endif
