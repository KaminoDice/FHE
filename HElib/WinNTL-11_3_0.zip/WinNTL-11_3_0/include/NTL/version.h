
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "11.3.0"

#define NTL_MAJOR_VERSION  (11)
#define NTL_MINOR_VERSION  (3)
#define NTL_REVISION       (0)

#endif

