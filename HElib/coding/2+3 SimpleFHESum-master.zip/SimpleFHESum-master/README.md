# SimpleFHESum
Summation of 2 + 3 using Fully Homomorphic Encryption (HElib)
Code constructed from studying the samples provided at:
http://www.slideshare.net/ssuser4c5f79/h-elib
http://tommd.github.io/posts/HELib-Intro.html
https://pwnhome.wordpress.com/2013/05/03/guide-to-helib-1/
